import { NoticeAnalysis, NoticeActionItem, AppSettings } from '../types/notice';

const STORAGE_KEY_NOTICES = 'notice_mate_saved_notices_v1';
const STORAGE_KEY_SETTINGS = 'notice_mate_settings_v1';

const defaultSettings: AppSettings = {
  preferredLanguage: 'en',
  fontSize: 'normal',
  highContrast: false,
  ttsVoice: 'Kore',
  ttsSpeed: 1,
  defaultReminders: [1440, 60], // 1 day before, 1 hour before
};

export const getSettings = (): AppSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!raw) return defaultSettings;
    return { ...defaultSettings, ...JSON.parse(raw) };
  } catch (e) {
    console.error('Failed to load settings from localStorage:', e);
    return defaultSettings;
  }
};

export const saveSettings = (settings: AppSettings): void => {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
};

export const getNotices = (): NoticeAnalysis[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_NOTICES);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse saved notices:', e);
    return [];
  }
};

export const getNoticeById = (id: string): NoticeAnalysis | null => {
  const notices = getNotices();
  return notices.find((n) => n.id === id) || null;
};

export const saveNotice = (notice: NoticeAnalysis): void => {
  try {
    const notices = getNotices();
    const existingIndex = notices.findIndex((n) => n.id === notice.id);
    if (existingIndex >= 0) {
      notices[existingIndex] = notice;
    } else {
      notices.unshift(notice); // Newest first
    }
    localStorage.setItem(STORAGE_KEY_NOTICES, JSON.stringify(notices));
  } catch (e) {
    console.error('Failed to save notice to localStorage:', e);
  }
};

export const deleteNotice = (id: string): void => {
  try {
    const notices = getNotices().filter((n) => n.id !== id);
    localStorage.setItem(STORAGE_KEY_NOTICES, JSON.stringify(notices));
  } catch (e) {
    console.error('Failed to delete notice from localStorage:', e);
  }
};

export const updateActionItem = (
  noticeId: string,
  actionId: string,
  updates: Partial<NoticeActionItem>
): void => {
  try {
    const notices = getNotices();
    const notice = notices.find((n) => n.id === noticeId);
    if (!notice) return;

    const action = notice.actionItems.find((a) => a.id === actionId);
    if (!action) return;

    Object.assign(action, updates);
    localStorage.setItem(STORAGE_KEY_NOTICES, JSON.stringify(notices));
  } catch (e) {
    console.error('Failed to update action item:', e);
  }
};

export const updateCalendarEventSync = (
  noticeId: string,
  eventId: string,
  calendarEventId: string,
  htmlLink: string
): void => {
  try {
    const notices = getNotices();
    const notice = notices.find((n) => n.id === noticeId);
    if (!notice) return;

    const candidate = notice.calendarEvents.find((c) => c.id === eventId);
    if (candidate) {
      candidate.syncedEventId = calendarEventId;
      candidate.calendarHtmlLink = htmlLink;
      candidate.syncStatus = 'synced';
    }

    // Also update corresponding action item if matching
    const matchingAction = notice.actionItems.find(
      (a) => a.title.toLowerCase().includes(candidate?.title.toLowerCase() || '___') ||
             (candidate?.title.toLowerCase().includes(a.title.toLowerCase()) ?? false)
    );
    if (matchingAction) {
      matchingAction.calendarEventId = calendarEventId;
      matchingAction.calendarEventLink = htmlLink;
      matchingAction.calendarSyncStatus = 'synced';
    }

    localStorage.setItem(STORAGE_KEY_NOTICES, JSON.stringify(notices));
  } catch (e) {
    console.error('Failed to update calendar event sync in storage:', e);
  }
};

export const getAllActionItems = (): NoticeActionItem[] => {
  const notices = getNotices();
  const allActions: NoticeActionItem[] = [];

  for (const n of notices) {
    if (n.actionItems) {
      for (const a of n.actionItems) {
        allActions.push({
          ...a,
          noticeId: n.id,
          noticeTitle: n.title,
        });
      }
    }
  }

  return allActions;
};

export const clearAllData = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEY_NOTICES);
  } catch (e) {
    console.error('Failed to clear data:', e);
  }
};
