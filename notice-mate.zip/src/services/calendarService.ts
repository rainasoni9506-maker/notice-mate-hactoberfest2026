import { getAccessToken } from './firebaseAuth';
import { NoticeEventCandidate } from '../types/notice';

export interface CalendarEventPayload {
  summary: string;
  description: string;
  start: { date?: string; dateTime?: string; timeZone?: string };
  end: { date?: string; dateTime?: string; timeZone?: string };
  reminders?: {
    useDefault: boolean;
    overrides: Array<{ method: string; minutes: number }>;
  };
  extendedProperties?: {
    private: {
      sourceApp: string;
      noticeTitle?: string;
      sourceQuote?: string;
      candidateId?: string;
    };
  };
}

export interface GoogleCalendarEventResponse {
  id: string;
  summary: string;
  htmlLink: string;
  start: { date?: string; dateTime?: string };
  end: { date?: string; dateTime?: string };
  description?: string;
}

/**
 * Fetch upcoming events from Google Calendar to check for existing events and duplicates.
 */
export async function getUpcomingCalendarEvents(maxResults = 50): Promise<GoogleCalendarEventResponse[]> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Not authenticated with Google Calendar. Please connect your account.');
  }

  const now = new Date().toISOString();
  const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${encodeURIComponent(
    now
  )}&maxResults=${maxResults}&singleEvents=true&orderBy=startTime`;

  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Google Calendar API error: ${response.status} ${errorText}`);
  }

  const data = await response.json();
  return data.items || [];
}

/**
 * Check if a candidate event likely duplicates an existing event in the user's calendar.
 */
export async function checkForDuplicateEvent(
  candidate: NoticeEventCandidate
): Promise<{ isDuplicate: boolean; existingEvent?: GoogleCalendarEventResponse }> {
  try {
    const existingEvents = await getUpcomingCalendarEvents(40);
    const candidateSummary = candidate.title.toLowerCase().trim();
    const candidateDate = candidate.startDate;

    const match = existingEvents.find((evt) => {
      const evtSummary = (evt.summary || '').toLowerCase().trim();
      const evtDate = evt.start?.date || (evt.start?.dateTime ? evt.start.dateTime.split('T')[0] : '');

      const isSameDate = evtDate === candidateDate;
      const isTitleSimilar =
        evtSummary === candidateSummary ||
        evtSummary.includes(candidateSummary) ||
        candidateSummary.includes(evtSummary);

      return isSameDate && isTitleSimilar;
    });

    return {
      isDuplicate: !!match,
      existingEvent: match,
    };
  } catch (err) {
    console.warn('Could not check duplicates from Google Calendar:', err);
    return { isDuplicate: false };
  }
}

/**
 * Creates an event in Google Calendar.
 */
export async function createCalendarEvent(
  candidate: NoticeEventCandidate,
  noticeTitle?: string
): Promise<GoogleCalendarEventResponse> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Please connect your Google Calendar first.');
  }

  // Handle all-day vs timed event
  let startObj: { date?: string; dateTime?: string; timeZone?: string };
  let endObj: { date?: string; dateTime?: string; timeZone?: string };

  const userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';

  if (candidate.isAllDay || !candidate.startTime) {
    startObj = { date: candidate.startDate };
    // Google Calendar API all-day end date is exclusive, so if single day, next day
    const nextDate = new Date(candidate.endDate || candidate.startDate);
    nextDate.setDate(nextDate.getDate() + 1);
    const nextDateStr = nextDate.toISOString().split('T')[0];
    endObj = { date: nextDateStr };
  } else {
    // Has specific time
    const startDateTime = `${candidate.startDate}T${candidate.startTime}:00`;
    const endTime = candidate.endTime || candidate.startTime;
    const endDateTime = `${candidate.endDate || candidate.startDate}T${endTime}:00`;
    startObj = { dateTime: new Date(startDateTime).toISOString(), timeZone: userTimeZone };
    endObj = { dateTime: new Date(endDateTime).toISOString(), timeZone: userTimeZone };
  }

  // Reminder minutes setup
  const reminderMinutes = candidate.reminders && candidate.reminders.length > 0
    ? candidate.reminders
    : [1440, 60]; // default: 1 day before + 1 hour before

  const overrides = reminderMinutes.map((m) => ({ method: 'popup', minutes: m }));

  const description = [
    `Notice Mate Action Item: ${candidate.title}`,
    noticeTitle ? `Source Notice: ${noticeTitle}` : '',
    candidate.description ? `\nDetails: ${candidate.description}` : '',
    candidate.sourceQuote ? `\nExact Source Text:\n"${candidate.sourceQuote}"` : '',
    '\nAdded securely via Notice Mate',
  ]
    .filter(Boolean)
    .join('\n');

  const payload: CalendarEventPayload = {
    summary: candidate.title,
    description,
    start: startObj,
    end: endObj,
    reminders: {
      useDefault: false,
      overrides,
    },
    extendedProperties: {
      private: {
        sourceApp: 'NoticeMate',
        noticeTitle: noticeTitle || 'Notice',
        sourceQuote: candidate.sourceQuote || '',
        candidateId: candidate.id,
      },
    },
  };

  const response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to create calendar event: ${response.status} ${errorText}`);
  }

  const createdEvent = await response.json();
  return createdEvent;
}

/**
 * Delete an event from Google Calendar (Requires explicit confirmation from caller).
 */
export async function deleteCalendarEvent(eventId: string): Promise<boolean> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Please connect your Google Calendar.');
  }

  const response = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!response.ok && response.status !== 404 && response.status !== 410) {
    throw new Error(`Failed to delete event: ${response.status}`);
  }

  return true;
}
