import { getAccessToken } from './firebaseAuth';
import { NoticeActionItem } from '../types/notice';

export interface GoogleTaskList {
  id: string;
  title: string;
  updated: string;
}

export interface GoogleTaskItem {
  id: string;
  title: string;
  notes?: string;
  due?: string; // RFC 3339 timestamp, e.g. "2026-11-15T00:00:00.000Z"
  status: 'needsAction' | 'completed';
  webViewLink?: string;
}

export interface TaskSyncCandidate {
  id: string;
  title: string;
  description?: string;
  dueDate: string | null; // YYYY-MM-DD
  dueTime?: string | null;
  sourceNoticeTitle?: string;
  sourceQuote?: string;
  selected: boolean;
  priority?: 'high' | 'medium' | 'low';
  syncedTaskId?: string;
}

/**
 * Fetch all task lists for the authenticated user from Google Tasks API.
 */
export async function getGoogleTaskLists(): Promise<GoogleTaskList[]> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Not authenticated with Google Tasks. Please connect your account.');
  }

  const response = await fetch('https://tasks.googleapis.com/tasks/v1/users/@me/lists', {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Google Tasks API error (${response.status}): ${errorText}`);
  }

  const data = await response.json();
  return data.items || [];
}

/**
 * Fetch tasks in a specific task list to check for existing tasks and duplicates.
 */
export async function getTasksInList(taskListId: string = '@default'): Promise<GoogleTaskItem[]> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Please connect your Google Account.');
  }

  const response = await fetch(`https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks?maxResults=100`, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to fetch tasks: ${response.status} ${errorText}`);
  }

  const data = await response.json();
  return data.items || [];
}

/**
 * Create a single task in a Google Tasks list.
 */
export async function createGoogleTask(
  taskListId: string,
  candidate: TaskSyncCandidate
): Promise<GoogleTaskItem> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Google Tasks is not authenticated. Please connect your Google account.');
  }

  // Format RFC 3339 due date for Google Tasks (midnight UTC for the day)
  let formattedDue: string | undefined = undefined;
  if (candidate.dueDate) {
    formattedDue = `${candidate.dueDate}T00:00:00.000Z`;
  }

  // Build notes with source document attribution
  const notesLines: string[] = [];
  if (candidate.description) notesLines.push(candidate.description);
  if (candidate.dueTime) notesLines.push(`Scheduled Time: ${candidate.dueTime}`);
  if (candidate.sourceNoticeTitle) notesLines.push(`Source Document: ${candidate.sourceNoticeTitle}`);
  if (candidate.sourceQuote) notesLines.push(`Original Text: "${candidate.sourceQuote}"`);
  notesLines.push('Added via NoticeMate Academic Assistant');

  const payload: {
    title: string;
    notes: string;
    due?: string;
    status: 'needsAction';
  } = {
    title: candidate.title,
    notes: notesLines.join('\n\n'),
    status: 'needsAction',
  };

  if (formattedDue) {
    payload.due = formattedDue;
  }

  const response = await fetch(`https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to create task (${response.status}): ${errorText}`);
  }

  const createdTask = await response.json();
  return createdTask;
}

/**
 * Check if a candidate task already exists in the target Google Tasks list.
 */
export async function checkDuplicateTask(
  taskListId: string,
  candidate: TaskSyncCandidate
): Promise<{ isDuplicate: boolean; existingTask?: GoogleTaskItem }> {
  try {
    const existing = await getTasksInList(taskListId);
    const candidateTitle = candidate.title.toLowerCase().trim();

    const match = existing.find((t) => {
      const existingTitle = (t.title || '').toLowerCase().trim();
      const isTitleMatch =
        existingTitle === candidateTitle ||
        existingTitle.includes(candidateTitle) ||
        candidateTitle.includes(existingTitle);

      let isDateMatch = true;
      if (candidate.dueDate && t.due) {
        isDateMatch = t.due.startsWith(candidate.dueDate);
      }

      return isTitleMatch && isDateMatch;
    });

    return {
      isDuplicate: !!match,
      existingTask: match,
    };
  } catch (err) {
    console.warn('Could not check duplicates from Google Tasks:', err);
    return { isDuplicate: false };
  }
}
