export type SpeechStatus = 'idle' | 'loading' | 'playing' | 'paused' | 'error';

class SpeechService {
  private currentAudio: HTMLAudioElement | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private status: SpeechStatus = 'idle';
  private statusListeners: Array<(status: SpeechStatus) => void> = [];
  private rate: number = 1;

  public onStatusChange(callback: (status: SpeechStatus) => void) {
    this.statusListeners.push(callback);
    callback(this.status);
    return () => {
      this.statusListeners = this.statusListeners.filter((cb) => cb !== callback);
    };
  }

  private setStatus(newStatus: SpeechStatus) {
    this.status = newStatus;
    this.statusListeners.forEach((cb) => cb(this.status));
  }

  public getStatus(): SpeechStatus {
    return this.status;
  }

  public setSpeed(rate: number) {
    this.rate = rate;
    if (this.currentAudio) {
      this.currentAudio.playbackRate = rate;
    }
    if (this.currentUtterance) {
      this.currentUtterance.rate = rate;
    }
  }

  /**
   * Speak text using server-side Gemini TTS first, falling back to Web Speech API.
   */
  public async speak(text: string, language: 'en' | 'hi' = 'en', voiceName: string = 'Kore'): Promise<void> {
    this.stop();
    this.setStatus('loading');

    const cleanText = text.replace(/[*#_`]/g, '').trim();
    if (!cleanText) {
      this.setStatus('idle');
      return;
    }

    try {
      // Attempt Gemini AI Neural TTS via backend endpoint
      const response = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: cleanText,
          voiceName: voiceName || 'Kore',
          stylePrompt: language === 'hi' 
            ? 'Spoken in warm, clear, accessible Hindi'
            : 'Spoken in warm, reassuring, accessible English',
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.audioBase64) {
          const audioSrc = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
          const audio = new Audio(audioSrc);
          this.currentAudio = audio;
          audio.playbackRate = this.rate;

          audio.onplay = () => this.setStatus('playing');
          audio.onpause = () => {
            if (this.status !== 'idle') this.setStatus('paused');
          };
          audio.onended = () => {
            this.setStatus('idle');
            this.currentAudio = null;
          };
          audio.onerror = (e) => {
            console.warn('Audio playback error, falling back to browser speech:', e);
            this.fallbackBrowserSpeech(cleanText, language);
          };

          await audio.play();
          return;
        }
      }
      // If server TTS returned error or missing audio, fall back
      this.fallbackBrowserSpeech(cleanText, language);
    } catch (err) {
      console.warn('Gemini TTS failed, falling back to browser speech:', err);
      this.fallbackBrowserSpeech(cleanText, language);
    }
  }

  private fallbackBrowserSpeech(text: string, language: 'en' | 'hi') {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      this.setStatus('error');
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    this.currentUtterance = utterance;
    utterance.lang = language === 'hi' ? 'hi-IN' : 'en-US';
    utterance.rate = this.rate;

    utterance.onstart = () => this.setStatus('playing');
    utterance.onpause = () => this.setStatus('paused');
    utterance.onresume = () => this.setStatus('playing');
    utterance.onend = () => {
      this.setStatus('idle');
      this.currentUtterance = null;
    };
    utterance.onerror = () => {
      this.setStatus('error');
      this.currentUtterance = null;
    };

    window.speechSynthesis.speak(utterance);
  }

  public pause() {
    if (this.currentAudio && !this.currentAudio.paused) {
      this.currentAudio.pause();
      this.setStatus('paused');
    } else if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      this.setStatus('paused');
    }
  }

  public resume() {
    if (this.currentAudio && this.currentAudio.paused) {
      this.currentAudio.play();
      this.setStatus('playing');
    } else if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      this.setStatus('playing');
    }
  }

  public stop() {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.currentUtterance = null;
    }
    this.setStatus('idle');
  }
}

export const speechService = new SpeechService();
