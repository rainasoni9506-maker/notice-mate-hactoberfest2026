/**
 * Utility for fast, client-side document optimization and safe base64 encoding.
 * Supports PDF documents, DOCX files, TXT files, and auto-downscaled camera photos / images.
 */

export interface OptimizedFileResult {
  base64Data?: string;
  textData?: string;
  mimeType: 'image/jpeg' | 'image/png' | 'application/pdf' | 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' | 'text/plain';
  fileName: string;
  originalSize: number;
  optimizedSize: number;
  isImage: boolean;
  isText: boolean;
}

export async function optimizeDocumentFile(file: File): Promise<OptimizedFileResult> {
  const originalSize = file.size;
  const fileName = file.name;
  const rawType = (file.type || '').toLowerCase();
  const lowerName = fileName.toLowerCase();

  // 1. Plain Text files (.txt)
  if (rawType.includes('text/plain') || lowerName.endsWith('.txt')) {
    const textData = await readRawText(file);
    return {
      textData,
      mimeType: 'text/plain',
      fileName,
      originalSize,
      optimizedSize: originalSize,
      isImage: false,
      isText: true,
    };
  }

  // 2. Word Documents (.docx)
  if (
    rawType.includes('wordprocessingml') ||
    rawType.includes('msword') ||
    lowerName.endsWith('.docx')
  ) {
    const base64Data = await readRawBase64(file);
    return {
      base64Data,
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      fileName,
      originalSize,
      optimizedSize: originalSize,
      isImage: false,
      isText: false,
    };
  }

  // 3. PDF Documents (.pdf)
  if (rawType.includes('pdf') || lowerName.endsWith('.pdf')) {
    const base64Data = await readRawBase64(file);
    return {
      base64Data,
      mimeType: 'application/pdf',
      fileName,
      originalSize,
      optimizedSize: originalSize,
      isImage: false,
      isText: false,
    };
  }

  // 4. Images: JPEG, PNG, WEBP
  const isJpeg = rawType.includes('jpeg') || rawType.includes('jpg') || lowerName.match(/\.jpe?g$/);
  const isPng = rawType.includes('png') || lowerName.endsWith('.png');
  const isWebp = rawType.includes('webp') || lowerName.endsWith('.webp');

  if (!isJpeg && !isPng && !isWebp) {
    throw new Error('Unsupported format. Please upload a PDF, DOCX, TXT file or a clear JPG/PNG image.');
  }

  // Downsample large camera photos/images on client canvas to 1600px
  try {
    const objectUrl = URL.createObjectURL(file);
    const img = await loadImage(objectUrl);
    URL.revokeObjectURL(objectUrl);

    const maxDim = 1600; // Optimal resolution for small printed text OCR
    let { width, height } = img;

    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', { alpha: false });

    if (!ctx) {
      const base64 = await readRawBase64(file);
      return {
        base64Data: base64,
        mimeType: isPng ? 'image/png' : 'image/jpeg',
        fileName,
        originalSize,
        optimizedSize: originalSize,
        isImage: true,
        isText: false,
      };
    }

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    const base64Data = dataUrl.split(',')[1] || '';
    const optimizedSize = Math.round((base64Data.length * 3) / 4);

    return {
      base64Data,
      mimeType: 'image/jpeg',
      fileName,
      originalSize,
      optimizedSize,
      isImage: true,
      isText: false,
    };
  } catch (err) {
    console.warn('Canvas optimization fallback to direct file reading:', err);
    const base64Data = await readRawBase64(file);
    return {
      base64Data,
      mimeType: isPng ? 'image/png' : 'image/jpeg',
      fileName,
      originalSize,
      optimizedSize: originalSize,
      isImage: true,
      isText: false,
    };
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image for processing'));
    img.src = src;
  });
}

function readRawText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string) || '');
    reader.onerror = () => reject(new Error('Failed to read text file'));
    reader.readAsText(file);
  });
}

function readRawBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const commaIdx = result.indexOf(',');
      const base64 = commaIdx >= 0 ? result.slice(commaIdx + 1) : result;
      resolve(base64);
    };
    reader.onerror = () => reject(new Error('Failed to read file from disk'));
    reader.readAsDataURL(file);
  });
}
