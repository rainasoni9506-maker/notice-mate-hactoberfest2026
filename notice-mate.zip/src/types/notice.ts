export type DocumentType = 'notice' | 'datesheet' | 'timetable' | 'assignment' | 'appointment' | 'general';

export interface NoticeFact {
  id: string;
  category: 'deadline' | 'exam' | 'fee' | 'document' | 'eligibility' | 'instruction' | 'restriction' | 'contact' | string;
  title: string;
  description: string;
  sourceQuote: string;
  pageOrSection: string;
  importance: 'high' | 'medium' | 'low';
}

export interface NoticeActionItem {
  id: string;
  title: string;
  description: string;
  dueDate: string | null; // YYYY-MM-DD or null
  dueTime: string | null; // HH:MM or null
  isAllDay: boolean;
  isDeadlinePassed: boolean;
  isDateAmbiguous: boolean;
  ambiguityReason?: string;
  sourceQuote: string;
  category: 'payment' | 'form_submission' | 'document_prep' | 'attendance' | 'verification' | 'study' | 'assignment' | 'class' | 'other' | string;
  completed?: boolean;
  noticeId?: string;
  noticeTitle?: string;
  calendarEventId?: string;
  calendarEventLink?: string;
  calendarSyncStatus?: 'not_synced' | 'synced' | 'failed';
  googleTaskId?: string;
  googleTaskSyncStatus?: 'not_synced' | 'synced' | 'failed';
  priority?: 'high' | 'medium' | 'low';
  isSuggestedPrep?: boolean;
}

export interface NoticeEventCandidate {
  id: string;
  title: string;
  description: string;
  startDate: string; // YYYY-MM-DD
  startTime?: string; // HH:MM
  endDate: string; // YYYY-MM-DD
  endTime?: string; // HH:MM
  isAllDay: boolean;
  eventType: 'deadline' | 'exam' | 'submission' | 'meeting' | 'verification' | 'class' | string;
  sourceQuote: string;
  isAmbiguous: boolean;
  ambiguityNote?: string;
  selected?: boolean;
  reminders?: number[]; // minutes before event
  syncedEventId?: string;
  calendarHtmlLink?: string;
  syncStatus?: 'idle' | 'syncing' | 'synced' | 'error';
  errorMessage?: string;
  location?: string;
}

export interface NoticeSimpleSummaryContent {
  quickSummary: string;
  whatThisMeansForYou: string;
  importantInstructions: string[];
  conditionsAndEligibility: string[];
  requiredDocuments: string[];
  feesAndPenalties: string[];
}

export interface NoticeAnalysis {
  id: string;
  title: string;
  issuingOrganization: string;
  noticeReferenceNo?: string;
  announcementDate?: string;
  category: string;
  documentType?: DocumentType;
  simpleSummary: {
    en: NoticeSimpleSummaryContent;
    hi: NoticeSimpleSummaryContent;
  };
  facts: NoticeFact[];
  actionItems: NoticeActionItem[];
  calendarEvents: NoticeEventCandidate[];
  originalExtractedText: string;
  processingNotes?: string[];
  rawInputType: 'pdf' | 'image' | 'text' | 'docx' | 'txt';
  fileName?: string;
  createdAt: string;
}

export interface AppSettings {
  preferredLanguage: 'en' | 'hi';
  fontSize: 'normal' | 'large' | 'extralarge';
  highContrast: boolean;
  ttsVoice: 'Kore' | 'Zephyr' | 'Puck' | 'browser';
  ttsSpeed: number; // 0.8, 1, 1.2
  defaultReminders: number[]; // e.g. [1440, 60]
  defaultTaskListId?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestedActions?: Array<{
    label: string;
    actionType: 'open_notice' | 'sync_tasks' | 'view_calendar' | 'open_my_day';
    payload?: string;
  }>;
}

export interface DailyPlanItem {
  id: string;
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:MM
  type: 'fixed_event' | 'deadline' | 'study_prep' | 'user_task';
  priority: 'high' | 'medium' | 'low';
  sourceNoticeTitle?: string;
  sourceNoticeId?: string;
  actionItemId?: string;
  completed: boolean;
  isSuggested: boolean;
  hasConflict?: boolean;
  conflictDetails?: string;
  googleTaskId?: string;
}
