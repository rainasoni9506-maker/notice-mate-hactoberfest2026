import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User as UserIcon,
  RefreshCw,
  Calendar,
  CheckSquare,
  AlertTriangle,
  ChevronRight,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { ChatMessage, NoticeAnalysis } from '../types/notice';

interface AIChatPanelProps {
  isOpen: boolean;
  onClose: () => void;
  savedNotices: NoticeAnalysis[];
  activeNotice: NoticeAnalysis | null;
  onNavigateToTab: (tab: 'home' | 'notices' | 'actions' | 'calendar' | 'myday' | 'settings') => void;
  onOpenTasksSyncModal: () => void;
}

const DEFAULT_SUGGESTIONS = [
  'Summarize my latest notice.',
  'What deadlines are coming up?',
  'Create my to-do list for today.',
  'What exams do I have this week?',
  'Add my upcoming tasks to Google Tasks.',
  'Do I have any exam or timetable conflicts?',
];

export const AIChatPanel: React.FC<AIChatPanelProps> = ({
  isOpen,
  onClose,
  savedNotices,
  activeNotice,
  onNavigateToTab,
  onOpenTasksSyncModal,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome_msg',
      role: 'assistant',
      content:
        'Hi! I am your NoticeMate Academic Assistant. Ask me anything about your uploaded notices, datesheets, timetables, or deadlines, or click a suggestion below to plan your day!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  // Construct grounding context from all user's uploaded documents & timetable items
  const buildDocumentsContext = (): string => {
    if (savedNotices.length === 0) {
      return 'No notices, timetables, or datesheets uploaded yet.';
    }

    const contextSections = savedNotices.map((n, i) => {
      const dates = (n.calendarEvents || [])
        .map((e) => `• ${e.title}: ${e.startDate}${e.startTime ? ' at ' + e.startTime : ''} (${e.eventType})`)
        .join('\n');

      const actions = (n.actionItems || [])
        .map((a) => `• ${a.title}: Due ${a.dueDate || 'Unstated'}${a.dueTime ? ' ' + a.dueTime : ''} [${a.completed ? 'COMPLETED' : 'PENDING'}]`)
        .join('\n');

      return `--- DOCUMENT ${i + 1}: ${n.title} (${n.documentType || n.category}) ---
Issuing Body: ${n.issuingOrganization}
Summary: ${n.simpleSummary?.en?.quickSummary || 'N/A'}
Scheduled Dates & Events:
${dates || 'None listed'}
Action Items & Tasks:
${actions || 'None listed'}
Important Conditions:
${(n.simpleSummary?.en?.conditionsAndEligibility || []).join('; ') || 'None'}`;
    });

    return contextSections.join('\n\n');
  };

  const handleSendMessage = async (userText: string) => {
    const textToSend = userText.trim();
    if (!textToSend || isLoading) return;

    setErrorMessage(null);
    setInputValue('');

    const newMsg: ChatMessage = {
      id: `user_${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedHistory = [...messages, newMsg];
    setMessages(updatedHistory);
    setIsLoading(true);

    // Fast client-side quick triggers for direct UI navigation
    const lower = textToSend.toLowerCase();
    if (lower.includes('google task') || lower.includes('add to tasks') || lower.includes('sync task')) {
      setTimeout(() => {
        setIsLoading(false);
        setMessages((prev) => [
          ...prev,
          {
            id: `assistant_${Date.now()}`,
            role: 'assistant',
            content: "I've opened the Google Tasks sync tool for you! You can review and select which tasks to send directly to your Google Tasks account.",
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
        onOpenTasksSyncModal();
      }, 500);
      return;
    }

    if (lower.includes('my day') || lower.includes('daily plan') || lower.includes('to-do list for today')) {
      setTimeout(() => {
        setIsLoading(false);
        setMessages((prev) => [
          ...prev,
          {
            id: `assistant_${Date.now()}`,
            role: 'assistant',
            content: "I've organized your daily plan in the **My Day** dashboard! Taking you there now where you can see your scheduled classes, deadlines, and suggested preparations.",
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
        onNavigateToTab('myday');
      }, 600);
      return;
    }

    try {
      const documentsContext = buildDocumentsContext();
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedHistory.map((m) => ({ role: m.role, content: m.content })),
          documentsContext,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || 'Chat request failed.');
      }

      const data = await response.json();
      const botReply = data.reply || "I've reviewed your documents. Let me know if you need any specific details!";

      setMessages((prev) => [
        ...prev,
        {
          id: `assistant_${Date.now()}`,
          role: 'assistant',
          content: botReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err: any) {
      console.error('Chat error:', err);
      setErrorMessage(err.message || 'Unable to connect to assistant. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(inputValue);
    }
  };

  if (!isOpen) return null;

  return (
    <aside
      className="fixed inset-y-0 right-0 z-50 w-full sm:w-[410px] bg-[#FFF9F2] border-l border-[#EAE4E8] shadow-2xl flex flex-col animate-in slide-in-from-right duration-200"
      aria-label="AI Academic Assistant Chat"
    >
      {/* Chat Header */}
      <div className="p-4 bg-white border-b border-[#EAE4E8] flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center shadow-xs">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm font-bold text-[#373444]">NoticeMate AI</h2>
              <span className="w-2 h-2 rounded-full bg-[#4D7C5D]" title="Active" />
            </div>
            <p className="text-[11px] text-[#6F6B78]">Academic Assistant • Grounded in your notices</p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setMessages([messages[0]])}
            className="p-1.5 rounded-xl text-[#9C98A5] hover:text-[#373444] hover:bg-[#FFF9F2] transition-colors"
            title="Clear Chat"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2] transition-colors"
            aria-label="Close Assistant"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grounding Context Status Bar */}
      <div className="px-4 py-2 bg-[#E8DFF5]/30 border-b border-[#EAE4E8] flex items-center justify-between text-[11px] text-[#4F3F82]">
        <span className="flex items-center gap-1.5 font-medium truncate">
          <Sparkles className="w-3 h-3 text-[#8273B8] shrink-0" />
          <span>{savedNotices.length} Document(s) Loaded in Context</span>
        </span>
        <button
          type="button"
          onClick={() => onNavigateToTab('myday')}
          className="text-[#8273B8] font-bold hover:underline shrink-0 text-[11px]"
        >
          View My Day →
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex items-start gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.role === 'assistant' && (
              <div className="w-7 h-7 rounded-xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs sm:text-[13px] leading-relaxed shadow-xs ${
                m.role === 'user'
                  ? 'bg-[#8273B8] text-white rounded-br-xs'
                  : 'bg-white text-[#373444] border border-[#EAE4E8] rounded-bl-xs'
              }`}
            >
              <div className="whitespace-pre-wrap">{m.content}</div>
              <div
                className={`text-[9px] mt-1 text-right ${
                  m.role === 'user' ? 'text-white/70' : 'text-[#9C98A5]'
                }`}
              >
                {m.timestamp}
              </div>
            </div>

            {m.role === 'user' && (
              <div className="w-7 h-7 rounded-xl bg-[#DDEBDD] text-[#254A30] flex items-center justify-center shrink-0 mt-0.5">
                <UserIcon className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center shrink-0 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white border border-[#EAE4E8] rounded-2xl px-3.5 py-2 text-xs text-[#6F6B78] flex items-center gap-2 shadow-xs">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#8273B8]" />
              <span>Thinking with your documents...</span>
            </div>
          </div>
        )}

        {errorMessage && (
          <div className="p-3 rounded-2xl bg-[#F8E2D5] border border-[#EAC2AE] text-xs text-[#6E3C21] flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#C75A22] shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="p-2.5 bg-white/70 border-t border-[#EAE4E8]">
        <p className="text-[10px] font-bold text-[#9C98A5] uppercase tracking-wider px-1.5 mb-1.5">
          Suggested Questions
        </p>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {DEFAULT_SUGGESTIONS.map((suggestion, i) => (
            <button
              key={i}
              type="button"
              disabled={isLoading}
              onClick={() => handleSendMessage(suggestion)}
              className="px-2.5 py-1 rounded-xl bg-white border border-[#EAE4E8] hover:border-[#8273B8] hover:bg-[#E8DFF5]/40 text-[11px] font-medium text-[#373444] shrink-0 transition-colors cursor-pointer disabled:opacity-50"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <div className="p-3 bg-white border-t border-[#EAE4E8]">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoading}
            placeholder="Ask about datesheets, deadlines, or timetable..."
            className="flex-1 px-3.5 py-2.5 rounded-2xl border border-[#EAE4E8] bg-[#FFF9F2]/60 text-xs text-[#373444] placeholder-[#9C98A5] focus:outline-none focus:border-[#8273B8] focus:bg-white"
          />
          <button
            type="button"
            onClick={() => handleSendMessage(inputValue)}
            disabled={isLoading || !inputValue.trim()}
            className="w-9 h-9 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] text-white flex items-center justify-center shrink-0 shadow-xs disabled:opacity-40 transition-transform active:scale-95 cursor-pointer"
            aria-label="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
