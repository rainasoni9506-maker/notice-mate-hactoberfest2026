import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  ExternalLink,
  CheckCircle2,
  Trash2,
  RefreshCw,
  LogOut,
  AlertCircle,
  Clock,
  Sparkles,
  CalendarCheck
} from 'lucide-react';
import { User } from 'firebase/auth';
import { getUpcomingCalendarEvents, deleteCalendarEvent, GoogleCalendarEventResponse } from '../services/calendarService';
import { NoticeAnalysis } from '../types/notice';

interface CalendarViewProps {
  user: User | null;
  onConnectCalendar: () => void;
  onDisconnectCalendar: () => void;
  savedNotices: NoticeAnalysis[];
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  user,
  onConnectCalendar,
  onDisconnectCalendar,
  savedNotices,
}) => {
  const [events, setEvents] = useState<GoogleCalendarEventResponse[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [deleteConfirmEvent, setDeleteConfirmEvent] = useState<GoogleCalendarEventResponse | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchEvents = async () => {
    if (!user) return;
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const items = await getUpcomingCalendarEvents(30);
      // Filter or highlight events related to notices or NoticeMate
      setEvents(items);
    } catch (err: any) {
      console.error('Error fetching calendar events:', err);
      setErrorMessage(err.message || 'Failed to load upcoming calendar events.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchEvents();
    }
  }, [user]);

  // Execute deletion with explicit confirmation dialog (Mandatory for Workspace mutations)
  const handleConfirmDelete = async () => {
    if (!deleteConfirmEvent) return;
    setIsDeleting(true);
    try {
      await deleteCalendarEvent(deleteConfirmEvent.id);
      setEvents((prev) => prev.filter((e) => e.id !== deleteConfirmEvent.id));
      setDeleteConfirmEvent(null);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to delete event from Google Calendar.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Extract all calendar events saved in local notices
  const localSyncedEvents = savedNotices.flatMap((n) =>
    (n.calendarEvents || [])
      .filter((c) => c.syncedEventId || c.calendarHtmlLink)
      .map((c) => ({
        ...c,
        noticeTitle: n.title,
      }))
  );

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-10 h-10 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
                <CalendarIcon className="w-5 h-5" />
              </span>
              <h1 className="text-2xl font-bold text-[#373444] tracking-tight">
                Google Calendar Deadlines
              </h1>
            </div>
            <p className="text-sm text-[#6F6B78]">
              Keep every exam date, fee cutoff, and document submission scheduled seamlessly in one place.
            </p>
          </div>

          {user ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={fetchEvents}
                disabled={isLoading}
                className="px-3.5 py-2 rounded-2xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#373444] hover:bg-[#FFF9F2] shadow-xs flex items-center gap-1.5"
                title="Refresh events from Google Calendar"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-[#8273B8] ${isLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>

              <button
                type="button"
                onClick={onDisconnectCalendar}
                className="px-3.5 py-2 rounded-2xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#6E3C21] hover:bg-[#F8E2D5]/30 shadow-xs flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Disconnect</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onConnectCalendar}
              className="px-5 py-2.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-sm font-semibold shadow-xs flex items-center gap-2"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Connect Google Calendar</span>
            </button>
          )}
        </div>

        {/* Connection status notification */}
        {user ? (
          <div className="mt-4 p-3 rounded-2xl bg-[#DDEBDD]/50 border border-[#BDD6BD] flex items-center justify-between text-xs text-[#254A30]">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#2F7343]" />
              Signed in as <strong>{user.email}</strong>. Live synchronization active.
            </span>
            <a
              href="https://calendar.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#2F7343] font-bold underline flex items-center gap-1 hover:text-[#183921]"
            >
              Open Google Calendar Web
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        ) : (
          <div className="mt-4 p-4 rounded-2xl bg-[#FFF9F2] border border-[#EAE4E8] text-xs text-[#6F6B78] flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#8273B8]" />
            <span>
              Connect your calendar to view live schedule updates, set smartphone notifications, and sync notice action items.
            </span>
          </div>
        )}
      </div>

      {/* Error Banner */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-[#F8E2D5] border border-[#EAC2AE] text-xs text-[#6E3C21] flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-[#C75A22] shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Events List */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-[#373444] flex items-center justify-between">
          <span>Scheduled Notice Events</span>
          <span className="text-xs text-[#6F6B78] font-normal">
            {events.length} event(s) in primary calendar
          </span>
        </h2>

        {isLoading ? (
          <div className="py-12 text-center text-sm text-[#6F6B78] space-y-2">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-[#8273B8]" />
            <p>Fetching upcoming events from your Google Calendar...</p>
          </div>
        ) : events.length > 0 ? (
          <div className="space-y-3">
            {(() => {
              const dateCountMap = events.reduce((acc: Record<string, number>, evt) => {
                const d = evt.start?.date || evt.start?.dateTime?.split('T')[0] || '';
                if (d) acc[d] = (acc[d] || 0) + 1;
                return acc;
              }, {});

              return events.map((evt) => {
                const startDate = evt.start?.date || evt.start?.dateTime?.split('T')[0] || '';
                const startTime = evt.start?.dateTime ? evt.start.dateTime.split('T')[1]?.slice(0, 5) : null;
                const dateCount = dateCountMap[startDate] || 0;
                const hasConflict = dateCount > 1;
                const isNoticeMateEvent = evt.description?.includes('Notice Mate') || false;

              return (
                <div
                  key={evt.id}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isNoticeMateEvent
                      ? 'bg-[#E8DFF5]/20 border-[#8273B8]/30 hover:border-[#8273B8]'
                      : 'bg-[#FFF9F2]/40 border-[#EAE4E8]'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-bold text-[#373444]">
                        {evt.summary || 'Untitled Event'}
                      </h3>
                      {isNoticeMateEvent && (
                        <span className="px-2 py-0.5 rounded-full bg-[#E8DFF5] text-[#4F3F82] text-[10px] font-bold">
                          Notice Mate
                        </span>
                      )}
                      {hasConflict && (
                        <span className="px-2 py-0.5 rounded-full bg-[#F8E2D5] text-[#C75A22] text-[10px] font-bold flex items-center gap-1" title="Another event is scheduled on this same date">
                          <AlertCircle className="w-3 h-3" />
                          <span>Same-day Conflict ({dateCount} events)</span>
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-[#6F6B78]">
                      <span className="flex items-center gap-1 font-semibold text-[#373444]">
                        <CalendarIcon className="w-3.5 h-3.5 text-[#8273B8]" />
                        {startDate}
                      </span>
                      {startTime ? (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {startTime}
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.2 rounded bg-white border border-[#EAE4E8] text-[10px]">
                          All-day
                        </span>
                      )}
                    </div>

                    {evt.description && (
                      <p className="text-xs text-[#6F6B78] line-clamp-2 max-w-xl">
                        {evt.description.split('\n')[0]}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    {evt.htmlLink && (
                      <a
                        href={evt.htmlLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-xl bg-white border border-[#EAE4E8] hover:bg-[#FFF9F2] text-xs font-semibold text-[#373444] shadow-xs flex items-center gap-1"
                      >
                        <span>Open Event</span>
                        <ExternalLink className="w-3 h-3 text-[#8273B8]" />
                      </a>
                    )}

                    <button
                      type="button"
                      onClick={() => setDeleteConfirmEvent(evt)}
                      className="p-2 rounded-xl text-[#9C98A5] hover:text-[#C75A22] hover:bg-[#F8E2D5]/40 transition-colors"
                      title="Remove event from Google Calendar"
                      aria-label="Delete event"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            });
          })()}
          </div>
        ) : (
          <div className="py-12 text-center text-[#6F6B78] space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-[#FFF9F2] text-[#8273B8] flex items-center justify-center mx-auto">
              <CalendarCheck className="w-6 h-6" />
            </div>
            <p className="font-semibold text-sm text-[#373444]">
              {user ? 'No upcoming events found on your primary calendar.' : 'Connect your calendar to view synced events.'}
            </p>
            <p className="text-xs max-w-md mx-auto">
              Upload a notice on the Home page, review the extracted dates, and click "Add Dates to Google Calendar" to see them here!
            </p>
          </div>
        )}
      </div>

      {/* Mandatory User Confirmation Dialog before Deleting Calendar Events */}
      {deleteConfirmEvent && (
        <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#EAE4E8] shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#F8E2D5] text-[#C75A22] flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#373444]">
                  Delete Calendar Event?
                </h3>
                <p className="text-xs text-[#6F6B78]">
                  Confirmation required for calendar modification
                </p>
              </div>
            </div>

            <p className="text-sm text-[#373444] leading-relaxed">
              Are you sure you want to remove <strong>"{deleteConfirmEvent.summary}"</strong> from your Google Calendar? This action cannot be undone.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmEvent(null)}
                className="px-4 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#6F6B78] hover:bg-[#FFF9F2]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-5 py-2 rounded-xl bg-[#C75A22] hover:bg-[#A84817] text-white text-xs font-bold shadow-xs flex items-center gap-1.5"
              >
                {isDeleting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                <span>Delete Event</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
