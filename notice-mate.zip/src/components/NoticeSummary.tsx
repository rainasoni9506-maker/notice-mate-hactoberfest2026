import React, { useState } from 'react';
import { Volume2, VolumeX, Globe2, FileText, CheckCircle2, AlertTriangle, ShieldAlert, Sparkles, BookOpen, ChevronDown, ChevronUp } from 'lucide-react';
import { NoticeAnalysis, NoticeSimpleSummaryContent } from '../types/notice';
import { speechService, SpeechStatus } from '../services/speechService';

interface NoticeSummaryProps {
  analysis: NoticeAnalysis;
  onOpenCalendarReview: () => void;
}

export const NoticeSummary: React.FC<NoticeSummaryProps> = ({
  analysis,
  onOpenCalendarReview,
}) => {
  const [lang, setLang] = useState<'en' | 'hi'>('en');
  const [showOriginal, setShowOriginal] = useState(false);
  const [speechStatus, setSpeechStatus] = useState<SpeechStatus>('idle');

  React.useEffect(() => {
    const unsubscribe = speechService.onStatusChange(setSpeechStatus);
    return () => unsubscribe();
  }, []);

  const content: NoticeSimpleSummaryContent = analysis.simpleSummary[lang] || analysis.simpleSummary.en;

  const handleListenSummary = () => {
    if (speechStatus === 'playing') {
      speechService.pause();
    } else if (speechStatus === 'paused') {
      speechService.resume();
    } else {
      const textToRead = `${content.quickSummary}. ${content.whatThisMeansForYou}. Instructions: ${content.importantInstructions.join('. ')}`;
      speechService.speak(textToRead, lang);
    }
  };

  const handleListenOriginal = () => {
    if (speechStatus === 'playing') {
      speechService.pause();
    } else {
      speechService.speak(analysis.originalExtractedText || content.quickSummary, lang);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Notice Title, Organization, Language Selector, and Speech Button */}
      <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-[#E8DFF5] text-[#4F3F82] text-xs font-bold">
                {analysis.category || 'Official Notice'}
              </span>
              {analysis.noticeReferenceNo && (
                <span className="px-2 py-0.5 rounded-md bg-[#FFF9F2] text-[#6F6B78] text-xs font-mono border border-[#EAE4E8]">
                  Ref: {analysis.noticeReferenceNo}
                </span>
              )}
              {analysis.announcementDate && (
                <span className="text-xs text-[#6F6B78]">
                  Issued: {analysis.announcementDate}
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#373444] tracking-tight">
              {analysis.title}
            </h2>
            <p className="text-sm text-[#6F6B78] font-medium">
              {analysis.issuingOrganization}
            </p>
          </div>

          {/* Controls: Language Selector and Speech Button */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {/* Language Selector */}
            <div className="inline-flex rounded-2xl bg-[#FFF9F2] p-1 border border-[#EAE4E8]">
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  lang === 'en'
                    ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                    : 'text-[#6F6B78] hover:text-[#373444]'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setLang('hi')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  lang === 'hi'
                    ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                    : 'text-[#6F6B78] hover:text-[#373444]'
                }`}
              >
                हिन्दी (Hindi)
              </button>
            </div>

            {/* Read Aloud Button */}
            <button
              type="button"
              onClick={handleListenSummary}
              className={`px-3.5 py-2 rounded-2xl border text-xs font-semibold flex items-center gap-2 transition-all ${
                speechStatus === 'playing'
                  ? 'bg-[#DDEBDD] border-[#4D7C5D] text-[#254A30] animate-pulse'
                  : 'bg-white border-[#EAE4E8] text-[#373444] hover:bg-[#FFF9F2]'
              }`}
              title="Listen to simplified summary (Accessibility Text-to-Speech)"
              aria-label="Listen to simplified summary"
            >
              <Volume2 className="w-4 h-4 text-[#8273B8]" />
              <span>
                {speechStatus === 'playing' ? 'Pause Voice' : speechStatus === 'loading' ? 'Loading Voice...' : 'Listen to Summary'}
              </span>
            </button>
          </div>
        </div>

        {/* AI Disclaimer */}
        <div className="mt-4 pt-3 border-t border-[#EAE4E8] flex items-center justify-between text-[11px] text-[#9C98A5]">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#8273B8]" />
            Simplified by Notice Mate AI • Check original notice text below for legal verification.
          </span>
          <button
            type="button"
            onClick={() => setShowOriginal(!showOriginal)}
            className="text-[#8273B8] font-bold hover:underline flex items-center gap-1"
          >
            {showOriginal ? 'Hide Original' : 'View Original Notice Text'}
            {showOriginal ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Original Notice Text Collapsible Inspector */}
      {showOriginal && (
        <div className="bg-[#FFF9F2] rounded-3xl p-6 border border-[#EAE4E8] space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#373444] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#8273B8]" />
              <span>Verbatim Extracted Notice Text</span>
            </h3>
            <button
              type="button"
              onClick={handleListenOriginal}
              className="px-2.5 py-1 rounded-xl bg-white border border-[#EAE4E8] text-xs font-medium text-[#373444] hover:bg-[#E8DFF5]"
            >
              Listen to Full Text
            </button>
          </div>
          <div className="max-h-72 overflow-y-auto p-4 rounded-2xl bg-white border border-[#EAE4E8] font-mono text-xs leading-relaxed text-[#373444] whitespace-pre-wrap selection:bg-[#E8DFF5]">
            {analysis.originalExtractedText || 'No raw text available.'}
          </div>
        </div>
      )}

      {/* Quick Summary & What This Means for You */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Quick Summary Card */}
        <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-[#373444]">
              {lang === 'hi' ? 'त्वरित सारांश (Quick Summary)' : 'Quick Summary'}
            </h3>
          </div>
          <p className="text-sm sm:text-base text-[#373444] leading-relaxed">
            {content.quickSummary}
          </p>
        </div>

        {/* What This Means For You Card */}
        <div className="bg-[#DCEAF7]/30 rounded-3xl p-6 border border-[#C5DCF2] shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#DCEAF7] text-[#2C6294] flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-[#1D4A73]">
              {lang === 'hi' ? 'आपके लिए इसका क्या अर्थ है?' : 'What This Means for You'}
            </h3>
          </div>
          <p className="text-sm sm:text-base text-[#1D4A73] leading-relaxed">
            {content.whatThisMeansForYou}
          </p>
        </div>
      </div>

      {/* Instructions, Conditions, Documents & Fees Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Important Instructions */}
        <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-3">
          <h3 className="text-base font-bold text-[#373444] flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#4D7C5D]" />
            <span>{lang === 'hi' ? 'महत्वपूर्ण निर्देश' : 'Important Instructions'}</span>
          </h3>
          <ul className="space-y-2 text-sm text-[#373444]">
            {content.importantInstructions && content.importantInstructions.length > 0 ? (
              content.importantInstructions.map((instruction, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#DDEBDD] text-[#2F7343] font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{instruction}</span>
                </li>
              ))
            ) : (
              <li className="text-xs text-[#6F6B78] italic">No specific instructions specified.</li>
            )}
          </ul>
        </div>

        {/* Conditions and Eligibility */}
        <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-3">
          <h3 className="text-base font-bold text-[#373444] flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-[#C75A22]" />
            <span>{lang === 'hi' ? 'पात्रता व शर्तें' : 'Conditions & Eligibility'}</span>
          </h3>
          <ul className="space-y-2 text-sm text-[#373444]">
            {content.conditionsAndEligibility && content.conditionsAndEligibility.length > 0 ? (
              content.conditionsAndEligibility.map((cond, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C75A22] shrink-0 mt-2" />
                  <span className="leading-relaxed">{cond}</span>
                </li>
              ))
            ) : (
              <li className="text-xs text-[#6F6B78] italic">No specific conditions mentioned.</li>
            )}
          </ul>
        </div>

        {/* Required Documents */}
        <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-3">
          <h3 className="text-base font-bold text-[#373444] flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#8273B8]" />
            <span>{lang === 'hi' ? 'आवश्यक दस्तावेज (Checklist)' : 'Required Documents'}</span>
          </h3>
          <ul className="space-y-2 text-sm text-[#373444]">
            {content.requiredDocuments && content.requiredDocuments.length > 0 ? (
              content.requiredDocuments.map((doc, idx) => (
                <li key={idx} className="flex items-start gap-2.5 p-2 rounded-xl bg-[#FFF9F2] border border-[#EAE4E8]">
                  <span className="text-[#8273B8] font-bold text-xs mt-0.5">📄</span>
                  <span className="leading-relaxed font-medium">{doc}</span>
                </li>
              ))
            ) : (
              <li className="text-xs text-[#6F6B78] italic">No required documents listed.</li>
            )}
          </ul>
        </div>

        {/* Fees and Penalties */}
        <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-3">
          <h3 className="text-base font-bold text-[#373444] flex items-center gap-2">
            <span className="text-base">💳</span>
            <span>{lang === 'hi' ? 'शुल्क व विलंब शुल्क (Fees & Penalties)' : 'Fees & Payment Details'}</span>
          </h3>
          <ul className="space-y-2 text-sm text-[#373444]">
            {content.feesAndPenalties && content.feesAndPenalties.length > 0 ? (
              content.feesAndPenalties.map((fee, idx) => (
                <li key={idx} className="flex items-start gap-2.5 p-2 rounded-xl bg-[#F8E2D5]/30 border border-[#F8E2D5]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#E57A44] shrink-0 mt-2" />
                  <span className="leading-relaxed font-medium text-[#4D2816]">{fee}</span>
                </li>
              ))
            ) : (
              <li className="text-xs text-[#6F6B78] italic">No fees or charges mentioned in this notice.</li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};
