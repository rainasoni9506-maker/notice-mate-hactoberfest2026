import React, { useState, useEffect } from 'react';
import {
  CheckSquare,
  Square,
  Calendar,
  AlertCircle,
  ExternalLink,
  RefreshCw,
  X,
  Check,
  ListTodo,
  AlertTriangle
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  getGoogleTaskLists,
  createGoogleTask,
  checkDuplicateTask,
  GoogleTaskList,
  TaskSyncCandidate
} from '../services/tasksService';
import { NoticeActionItem } from '../types/notice';

interface GoogleTasksSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onConnectAccount: () => void;
  actionItems: NoticeActionItem[];
  onTasksSynced: (syncedTaskIds: Array<{ actionId: string; googleTaskId: string }>) => void;
}

export const GoogleTasksSyncModal: React.FC<GoogleTasksSyncModalProps> = ({
  isOpen,
  onClose,
  user,
  onConnectAccount,
  actionItems,
  onTasksSynced,
}) => {
  const [candidates, setCandidates] = useState<TaskSyncCandidate[]>([]);
  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>('@default');
  const [isLoadingLists, setIsLoadingLists] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [duplicateWarnings, setDuplicateWarnings] = useState<Record<string, string>>({});
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [syncResults, setSyncResults] = useState<{
    succeeded: Array<{ title: string; id: string }>;
    failed: Array<{ title: string; error: string }>;
  } | null>(null);

  // Initialize candidates from actionItems
  useEffect(() => {
    if (isOpen) {
      setCandidates(
        actionItems.map((item) => ({
          id: item.id,
          title: item.title,
          description: item.description,
          dueDate: item.dueDate,
          dueTime: item.dueTime,
          sourceNoticeTitle: item.noticeTitle,
          sourceQuote: item.sourceQuote,
          selected: !item.completed && item.googleTaskSyncStatus !== 'synced',
          priority: item.priority || 'medium',
          syncedTaskId: item.googleTaskId,
        }))
      );
      setSyncResults(null);
    }
  }, [isOpen, actionItems]);

  // Fetch Google Task Lists
  useEffect(() => {
    if (isOpen && user) {
      setIsLoadingLists(true);
      getGoogleTaskLists()
        .then((lists) => {
          setTaskLists(lists);
          if (lists.length > 0) {
            setSelectedListId(lists[0].id);
          }
        })
        .catch((err) => console.warn('Could not fetch task lists:', err))
        .finally(() => setIsLoadingLists(false));
    }
  }, [isOpen, user]);

  // Check duplicates in selected list
  useEffect(() => {
    if (user && selectedListId && candidates.length > 0) {
      candidates.forEach(async (cand) => {
        if (!cand.selected) return;
        const check = await checkDuplicateTask(selectedListId, cand);
        if (check.isDuplicate && check.existingTask) {
          setDuplicateWarnings((prev) => ({
            ...prev,
            [cand.id]: `Similar task exists in list: "${check.existingTask?.title}"`,
          }));
        }
      });
    }
  }, [user, selectedListId, candidates.length]);

  if (!isOpen) return null;

  const toggleSelect = (id: string) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, selected: !c.selected } : c))
    );
  };

  const updateCandidate = (id: string, updates: Partial<TaskSyncCandidate>) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const selectedCandidates = candidates.filter((c) => c.selected);

  const handleStartSync = () => {
    if (selectedCandidates.length === 0) return;
    setShowConfirmModal(true);
  };

  const handleConfirmSync = async () => {
    setShowConfirmModal(false);
    setIsSubmitting(true);

    const succeeded: Array<{ title: string; id: string }> = [];
    const failed: Array<{ title: string; error: string }> = [];
    const syncedMappings: Array<{ actionId: string; googleTaskId: string }> = [];

    for (const cand of selectedCandidates) {
      try {
        const created = await createGoogleTask(selectedListId, cand);
        succeeded.push({ title: cand.title, id: created.id });
        syncedMappings.push({ actionId: cand.id, googleTaskId: created.id });
      } catch (err: any) {
        console.error('Task creation failed:', cand.title, err);
        failed.push({ title: cand.title, error: err.message || 'API error' });
      }
    }

    setSyncResults({ succeeded, failed });
    setIsSubmitting(false);

    if (syncedMappings.length > 0) {
      onTasksSynced(syncedMappings);
    }
  };

  return (
    <div className="fixed inset-0 z-60 overflow-y-auto bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-[#EAE4E8] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 border-b border-[#EAE4E8] bg-[#FFF9F2] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center shadow-xs">
              <ListTodo className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#373444]">Sync to Google Tasks</h2>
              <p className="text-xs text-[#6F6B78]">
                Export confirmed notice tasks & assignment deadlines into your personal Google Tasks.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#6F6B78] hover:bg-white transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Account Authentication Banner */}
          {!user ? (
            <div className="p-4 rounded-2xl bg-[#DCEAF7]/50 border border-[#BAD8F2] flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="space-y-0.5 text-center sm:text-left">
                <p className="text-sm font-bold text-[#1D4A73]">Sign in to Google Tasks</p>
                <p className="text-xs text-[#2C6294]">
                  Authenticate with Google to create and sync tasks directly.
                </p>
              </div>
              <button
                type="button"
                onClick={onConnectAccount}
                className="px-4 py-2.5 rounded-2xl bg-white border border-[#BAD8F2] text-xs font-semibold text-[#1D4A73] hover:bg-white/80 shadow-xs flex items-center gap-2 shrink-0 cursor-pointer"
              >
                <ListTodo className="w-4 h-4 text-[#4285F4]" />
                <span>Connect Google Account</span>
              </button>
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-[#DDEBDD]/50 border border-[#BDD6BD] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#254A30]">
              <span className="flex items-center gap-2">
                <Check className="w-4 h-4 text-[#2F7343]" />
                Connected as <strong>{user.email}</strong>
              </span>

              {/* Task List Selector */}
              {taskLists.length > 0 && (
                <div className="flex items-center gap-1.5 self-start sm:self-auto">
                  <span className="text-[#345940] font-medium">Task List:</span>
                  <select
                    value={selectedListId}
                    onChange={(e) => setSelectedListId(e.target.value)}
                    className="bg-white border border-[#BDD6BD] rounded-xl px-2 py-1 text-xs font-semibold text-[#254A30] focus:outline-none"
                  >
                    {taskLists.map((tl) => (
                      <option key={tl.id} value={tl.id}>
                        {tl.title}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          )}

          {/* Sync Success / Failure Notification */}
          {syncResults && (
            <div className="space-y-2">
              {syncResults.succeeded.length > 0 && (
                <div className="p-4 rounded-2xl bg-[#DDEBDD] border border-[#BDD6BD] text-[#254A30] space-y-1.5 text-xs">
                  <p className="font-bold text-sm flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#2F7343]" />
                    <span>{syncResults.succeeded.length} task(s) synced to Google Tasks!</span>
                  </p>
                  <a
                    href="https://tasks.google.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-bold underline flex items-center gap-1 hover:text-[#183921] pt-1"
                  >
                    Open Google Tasks
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}

              {syncResults.failed.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-[#F8E2D5] border border-[#EAC2AE] text-xs text-[#6E3C21] space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-[#C75A22]" />
                    <span>Failed to sync {syncResults.failed.length} task(s):</span>
                  </p>
                  <ul className="pl-5 space-y-0.5">
                    {syncResults.failed.map((f, idx) => (
                      <li key={idx}>• {f.title}: {f.error}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Task Candidates Review List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-[#6F6B78] px-1">
              <span>Select tasks to export:</span>
              <button
                type="button"
                onClick={() => {
                  const allSelected = selectedCandidates.length === candidates.length;
                  setCandidates((prev) => prev.map((c) => ({ ...c, selected: !allSelected })));
                }}
                className="text-[#8273B8] hover:underline cursor-pointer"
              >
                {selectedCandidates.length === candidates.length ? 'Deselect All' : 'Select All'}
              </button>
            </div>

            {candidates.map((cand, idx) => (
              <div
                key={`${cand.id}_${idx}`}
                className={`p-4 rounded-2xl border transition-all ${
                  cand.selected
                    ? 'bg-white border-[#8273B8]/60 shadow-xs'
                    : 'bg-[#FFF9F2]/60 border-[#EAE4E8] opacity-60'
                }`}
              >
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={cand.selected}
                    onChange={() => toggleSelect(cand.id)}
                    className="mt-1 w-4 h-4 rounded text-[#8273B8] focus:ring-[#8273B8] cursor-pointer"
                    id={`task-cand-${cand.id}`}
                  />

                  <div className="flex-1 space-y-2">
                    <input
                      type="text"
                      value={cand.title}
                      onChange={(e) => updateCandidate(cand.id, { title: e.target.value })}
                      className="w-full p-2 rounded-xl border border-[#EAE4E8] bg-[#FFF9F2]/40 text-xs sm:text-sm font-bold text-[#373444] focus:outline-none focus:border-[#8273B8]"
                      placeholder="Task Title"
                    />

                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-[#8273B8]" />
                        <input
                          type="date"
                          value={cand.dueDate || ''}
                          onChange={(e) => updateCandidate(cand.id, { dueDate: e.target.value || null })}
                          className="p-1.5 rounded-lg border border-[#EAE4E8] bg-white text-xs text-[#373444] font-medium"
                        />
                      </div>

                      {cand.sourceNoticeTitle && (
                        <span className="px-2 py-0.5 rounded-md bg-[#FFF9F2] text-[#6F6B78] text-[11px] truncate max-w-[200px] border border-[#EAE4E8]">
                          From: {cand.sourceNoticeTitle}
                        </span>
                      )}

                      {cand.syncedTaskId && (
                        <span className="px-2 py-0.5 rounded-md bg-[#DDEBDD] text-[#254A30] text-[11px] font-semibold border border-[#BDD6BD]">
                          Already in Google Tasks
                        </span>
                      )}
                    </div>

                    {duplicateWarnings[cand.id] && (
                      <div className="p-2 rounded-xl bg-[#F8E2D5] border border-[#EAC2AE] text-[11px] text-[#6E3C21] flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-[#C75A22] shrink-0" />
                        <span>{duplicateWarnings[cand.id]}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {candidates.length === 0 && (
              <div className="py-8 text-center text-xs text-[#6F6B78]">
                No action items available to sync. Upload a notice or timetable to extract tasks!
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-[#EAE4E8] bg-[#FFF9F2] flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-xs text-[#6F6B78]">
            {selectedCandidates.length} task(s) selected
          </span>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#6F6B78] hover:bg-[#FFF9F2] cursor-pointer"
            >
              Cancel
            </button>

            {user ? (
              <button
                type="button"
                onClick={handleStartSync}
                disabled={isSubmitting || selectedCandidates.length === 0}
                className="px-6 py-2.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs sm:text-sm font-semibold shadow-xs flex items-center justify-center gap-2 w-full sm:w-auto cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Syncing...</span>
                  </>
                ) : (
                  <>
                    <ListTodo className="w-4 h-4" />
                    <span>Send {selectedCandidates.length} Tasks to Google Tasks</span>
                  </>
                )}
              </button>
            ) : (
              <button
                type="button"
                onClick={onConnectAccount}
                className="px-6 py-2.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs sm:text-sm font-semibold shadow-xs cursor-pointer"
              >
                Connect Google Account
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mandatory User Confirmation Modal Before Mutating Workspace Google Tasks */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-70 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#EAE4E8] shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
                <ListTodo className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#373444]">Confirm Google Tasks Export</h3>
                <p className="text-xs text-[#6F6B78]">Workspace Authorization Check</p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#373444] leading-relaxed">
              Are you sure you want to create <strong>{selectedCandidates.length}</strong> task(s) in your Google Tasks account (<strong>{user?.email}</strong>)?
            </p>

            <div className="max-h-36 overflow-y-auto p-3 rounded-xl bg-[#FFF9F2] border border-[#EAE4E8] text-xs space-y-1">
              {selectedCandidates.map((c) => (
                <div key={c.id} className="text-[#373444] truncate">
                  • <strong>{c.title}</strong> {c.dueDate ? `(Due ${c.dueDate})` : ''}
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#6F6B78]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSync}
                className="px-5 py-2 rounded-xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs font-bold shadow-xs flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Confirm & Add Tasks</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
