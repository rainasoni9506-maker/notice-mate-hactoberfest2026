import React from 'react';
import { FileText, CheckCircle2, Calendar, CheckSquare, History, Settings, Volume2, ShieldCheck, LogOut, Sun, Bot, Sparkles } from 'lucide-react';
import { User } from 'firebase/auth';

interface HeaderProps {
  currentTab: 'home' | 'notices' | 'actions' | 'calendar' | 'myday' | 'settings';
  onTabChange: (tab: 'home' | 'notices' | 'actions' | 'calendar' | 'myday' | 'settings') => void;
  user: User | null;
  onConnectCalendar: () => void;
  onDisconnectCalendar: () => void;
  savedNoticesCount: number;
  pendingActionsCount: number;
  fontSize: 'normal' | 'large' | 'extralarge';
  onFontSizeChange: (size: 'normal' | 'large' | 'extralarge') => void;
  isChatOpen: boolean;
  onToggleChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  user,
  onConnectCalendar,
  onDisconnectCalendar,
  savedNoticesCount,
  pendingActionsCount,
  fontSize,
  onFontSizeChange,
  isChatOpen,
  onToggleChat,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FFF9F2]/95 backdrop-blur-md border-b border-[#EAE4E8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Product Brand */}
          <button
            onClick={() => onTabChange('home')}
            className="flex items-center gap-3 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8273B8] rounded-xl p-1"
            aria-label="Notice Mate Home"
          >
            <div className="relative w-11 h-11 rounded-2xl bg-[#E8DFF5] flex items-center justify-center text-[#8273B8] shadow-sm group-hover:scale-105 transition-transform">
              <FileText className="w-6 h-6" />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[#DDEBDD] border-2 border-white flex items-center justify-center text-[#373444]">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#4D7C5D]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xl tracking-tight text-[#373444]">Notice Mate</span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-xs font-medium rounded-full bg-[#DDEBDD] text-[#345940]">
                  Accessibility Assistant
                </span>
              </div>
              <p className="text-xs text-[#6F6B78] font-medium hidden sm:block">From Notice to Action</p>
            </div>
          </button>

          {/* Center Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5 bg-white/70 p-1.5 rounded-2xl border border-[#EAE4E8] shadow-xs" aria-label="Main Navigation">
            <button
              onClick={() => onTabChange('home')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
                currentTab === 'home'
                  ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                  : 'text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2]'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Home</span>
            </button>

            <button
              onClick={() => onTabChange('notices')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
                currentTab === 'notices'
                  ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                  : 'text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2]'
              }`}
            >
              <History className="w-4 h-4" />
              <span>My Notices</span>
              {savedNoticesCount > 0 && (
                <span className="px-1.5 py-0.2 text-[11px] font-bold rounded-full bg-white text-[#373444] border border-[#EAE4E8]">
                  {savedNoticesCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onTabChange('actions')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
                currentTab === 'actions'
                  ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                  : 'text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2]'
              }`}
            >
              <CheckSquare className="w-4 h-4" />
              <span>Action Items</span>
              {pendingActionsCount > 0 && (
                <span className="px-1.5 py-0.2 text-[11px] font-bold rounded-full bg-[#F8E2D5] text-[#6E3C21]">
                  {pendingActionsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onTabChange('myday')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
                currentTab === 'myday'
                  ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                  : 'text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2]'
              }`}
            >
              <Sun className="w-4 h-4 text-[#E57A44]" />
              <span>My Day</span>
            </button>

            <button
              onClick={() => onTabChange('calendar')}
              className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
                currentTab === 'calendar'
                  ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                  : 'text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2]'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Calendar</span>
              {user && (
                <span className="w-2 h-2 rounded-full bg-[#4D7C5D]" title="Connected to Google Calendar" />
              )}
            </button>

            <button
              onClick={() => onTabChange('settings')}
              className={`px-3 py-2 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5 ${
                currentTab === 'settings'
                  ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                  : 'text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2]'
              }`}
              title="Settings"
            >
              <Settings className="w-4 h-4" />
              <span className="sr-only sm:not-sr-only">Settings</span>
            </button>
          </nav>

          {/* Right Header Area: AI Chat Toggle, Accessibility & Calendar Status */}
          <div className="flex items-center gap-2.5">
            {/* AI Assistant Drawer Toggle */}
            <button
              type="button"
              onClick={onToggleChat}
              className={`inline-flex items-center gap-2 px-3 py-2 rounded-2xl text-xs sm:text-sm font-bold border transition-all cursor-pointer ${
                isChatOpen
                  ? 'bg-[#8273B8] text-white border-[#8273B8] shadow-sm'
                  : 'bg-[#E8DFF5]/60 hover:bg-[#E8DFF5] text-[#4F3F82] border-[#D4C3EC]'
              }`}
              title="Open AI Assistant Panel"
              aria-label="Toggle AI Assistant"
            >
              <Bot className="w-4 h-4" />
              <span className="hidden sm:inline">AI Chat</span>
              <span className="w-2 h-2 rounded-full bg-[#4D7C5D]" />
            </button>
            {/* Font Size Selector for Accessibility */}
            <div className="hidden lg:flex items-center gap-1 bg-white border border-[#EAE4E8] rounded-xl p-1 text-xs font-semibold text-[#6F6B78]">
              <span className="px-1.5 text-[11px] uppercase tracking-wider text-[#9C98A5]">Text</span>
              <button
                onClick={() => onFontSizeChange('normal')}
                className={`px-2 py-1 rounded-lg transition-colors ${
                  fontSize === 'normal' ? 'bg-[#E8DFF5] text-[#373444]' : 'hover:bg-[#FFF9F2]'
                }`}
                title="Normal text size"
                aria-label="Normal text size"
              >
                A
              </button>
              <button
                onClick={() => onFontSizeChange('large')}
                className={`px-2 py-1 rounded-lg transition-colors ${
                  fontSize === 'large' ? 'bg-[#E8DFF5] text-[#373444] font-bold' : 'hover:bg-[#FFF9F2]'
                }`}
                title="Large text size"
                aria-label="Large text size"
              >
                A+
              </button>
              <button
                onClick={() => onFontSizeChange('extralarge')}
                className={`px-2 py-1 rounded-lg transition-colors ${
                  fontSize === 'extralarge' ? 'bg-[#E8DFF5] text-[#373444] font-bold' : 'hover:bg-[#FFF9F2]'
                }`}
                title="Extra large text size"
                aria-label="Extra large text size"
              >
                A++
              </button>
            </div>

            {/* Google Calendar Connection Status Button */}
            {user ? (
              <div className="flex items-center gap-2 bg-[#DDEBDD] border border-[#BDD6BD] pl-3 pr-2 py-1.5 rounded-2xl">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#2F7343] animate-pulse" />
                  <span className="text-xs font-medium text-[#254A30] hidden sm:inline max-w-[110px] truncate">
                    {user.displayName || user.email?.split('@')[0] || 'Calendar Connected'}
                  </span>
                </div>
                <button
                  onClick={onDisconnectCalendar}
                  className="p-1 rounded-lg text-[#254A30] hover:bg-white/60 transition-colors"
                  title="Disconnect Google Calendar"
                  aria-label="Disconnect Google Calendar"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={onConnectCalendar}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white hover:bg-[#F8E2D5]/40 text-[#373444] text-xs sm:text-sm font-semibold border border-[#EAE4E8] shadow-xs transition-all hover:border-[#8273B8]/30"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span className="hidden sm:inline">Connect Calendar</span>
                <span className="sm:hidden">Connect</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-[#EAE4E8]/60">
          <button
            onClick={() => onTabChange('home')}
            className={`flex flex-col items-center py-1 px-2 text-xs font-semibold ${
              currentTab === 'home' ? 'text-[#8273B8]' : 'text-[#6F6B78]'
            }`}
          >
            <FileText className="w-4 h-4 mb-0.5" />
            <span>Home</span>
          </button>
          <button
            onClick={() => onTabChange('notices')}
            className={`flex flex-col items-center py-1 px-2 text-xs font-semibold relative ${
              currentTab === 'notices' ? 'text-[#8273B8]' : 'text-[#6F6B78]'
            }`}
          >
            <History className="w-4 h-4 mb-0.5" />
            <span>Notices</span>
            {savedNoticesCount > 0 && (
              <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-[#8273B8]" />
            )}
          </button>
          <button
            onClick={() => onTabChange('actions')}
            className={`flex flex-col items-center py-1 px-2 text-xs font-semibold relative ${
              currentTab === 'actions' ? 'text-[#8273B8]' : 'text-[#6F6B78]'
            }`}
          >
            <CheckSquare className="w-4 h-4 mb-0.5" />
            <span>Actions</span>
            {pendingActionsCount > 0 && (
              <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-[#E57A44]" />
            )}
          </button>
          <button
            onClick={() => onTabChange('myday')}
            className={`flex flex-col items-center py-1 px-2 text-xs font-semibold ${
              currentTab === 'myday' ? 'text-[#8273B8]' : 'text-[#6F6B78]'
            }`}
          >
            <Sun className="w-4 h-4 mb-0.5 text-[#E57A44]" />
            <span>My Day</span>
          </button>
          <button
            onClick={() => onTabChange('calendar')}
            className={`flex flex-col items-center py-1 px-2 text-xs font-semibold ${
              currentTab === 'calendar' ? 'text-[#8273B8]' : 'text-[#6F6B78]'
            }`}
          >
            <Calendar className="w-4 h-4 mb-0.5" />
            <span>Calendar</span>
          </button>
          <button
            onClick={() => onTabChange('settings')}
            className={`flex flex-col items-center py-1 px-2 text-xs font-semibold ${
              currentTab === 'settings' ? 'text-[#8273B8]' : 'text-[#6F6B78]'
            }`}
          >
            <Settings className="w-4 h-4 mb-0.5" />
            <span>Settings</span>
          </button>
        </div>
      </div>
    </header>
  );
};
