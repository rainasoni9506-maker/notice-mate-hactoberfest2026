import React, { useState } from 'react';
import { History, FileText, Calendar, CheckSquare, Trash2, ArrowUpRight, Download, Sparkles, AlertCircle } from 'lucide-react';
import { NoticeAnalysis } from '../types/notice';

interface MyNoticesViewProps {
  notices: NoticeAnalysis[];
  onOpenNotice: (notice: NoticeAnalysis) => void;
  onDeleteNotice: (id: string) => void;
  onNavigateHome: () => void;
}

export const MyNoticesView: React.FC<MyNoticesViewProps> = ({
  notices,
  onOpenNotice,
  onDeleteNotice,
  onNavigateHome,
}) => {
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleExportJSON = (notice: NoticeAnalysis) => {
    const jsonStr = JSON.stringify(notice, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${notice.title.replace(/[^a-zA-Z0-9]/g, '_')}_analysis.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-10 h-10 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
                <History className="w-5 h-5" />
              </span>
              <h1 className="text-2xl font-bold text-[#373444] tracking-tight">
                My Saved Notices
              </h1>
            </div>
            <p className="text-sm text-[#6F6B78]">
              Revisit past notices, review checklists, and track previously scheduled deadlines.
            </p>
          </div>

          <button
            type="button"
            onClick={onNavigateHome}
            className="px-5 py-2.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-sm font-semibold shadow-xs flex items-center gap-2 self-start sm:self-auto"
          >
            <FileText className="w-4 h-4" />
            <span>Process New Notice</span>
          </button>
        </div>

        {/* Privacy Note */}
        <div className="mt-4 pt-3 border-t border-[#EAE4E8] flex items-center gap-2 text-xs text-[#9C98A5]">
          <Sparkles className="w-3.5 h-3.5 text-[#8273B8]" />
          <span>Notice Mate stores your notice history locally in your web browser. No private records are shared with third parties.</span>
        </div>
      </div>

      {/* Notices Grid / List */}
      {notices.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {notices.map((notice) => {
            const completedActions = (notice.actionItems || []).filter((a) => a.completed).length;
            const totalActions = notice.actionItems?.length || 0;
            const syncedEvents = (notice.calendarEvents || []).filter((c) => c.syncedEventId || c.calendarHtmlLink).length;

            return (
              <div
                key={notice.id}
                className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs hover:border-[#8273B8]/40 hover:shadow-sm transition-all space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-[#E8DFF5] text-[#4F3F82] text-xs font-bold">
                      {notice.category || 'Notice'}
                    </span>
                    <span className="text-xs text-[#9C98A5]">
                      {new Date(notice.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-[#373444] leading-snug line-clamp-2">
                    {notice.title}
                  </h3>

                  <p className="text-xs text-[#6F6B78] line-clamp-1">
                    {notice.issuingOrganization}
                  </p>

                  <p className="text-xs text-[#6F6B78] line-clamp-2 leading-relaxed bg-[#FFF9F2] p-2.5 rounded-xl border border-[#EAE4E8]">
                    {notice.simpleSummary?.en?.quickSummary || 'No summary available.'}
                  </p>

                  {/* Stats Badges */}
                  <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-[#DDEBDD]/50 text-[#254A30] font-medium border border-[#BDD6BD]">
                      <CheckSquare className="w-3.5 h-3.5" />
                      <span>{completedActions}/{totalActions} Tasks Done</span>
                    </span>

                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-[#DCEAF7]/50 text-[#1D4A73] font-medium border border-[#BAD8F2]">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{syncedEvents} Calendar Events</span>
                    </span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-3 border-t border-[#EAE4E8] flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleExportJSON(notice)}
                      className="p-2 rounded-xl text-[#6F6B78] hover:bg-[#FFF9F2] hover:text-[#373444] transition-colors"
                      title="Download JSON Export"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteConfirmId(notice.id)}
                      className="p-2 rounded-xl text-[#9C98A5] hover:text-[#C75A22] hover:bg-[#F8E2D5]/40 transition-colors"
                      title="Delete saved notice"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenNotice(notice)}
                    className="px-4 py-2 rounded-xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all"
                  >
                    <span>Open Notice</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-12 text-center border border-[#EAE4E8] shadow-xs space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-[#FFF9F2] text-[#8273B8] flex items-center justify-center mx-auto">
            <FileText className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-base text-[#373444]">No notices saved yet</h3>
          <p className="text-xs text-[#6F6B78] max-w-sm mx-auto">
            Once you upload a notice or test with a sample, it will appear here so you can revisit facts, checklists, and calendar events anytime.
          </p>
          <button
            type="button"
            onClick={onNavigateHome}
            className="mt-2 px-5 py-2.5 rounded-2xl bg-[#8273B8] text-white text-xs font-bold hover:bg-[#7263A8] shadow-xs"
          >
            Upload Your First Notice
          </button>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#EAE4E8] shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#F8E2D5] text-[#C75A22] flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-[#373444]">
                Remove Saved Notice?
              </h3>
            </div>
            <p className="text-xs text-[#6F6B78]">
              This will remove this notice and its task checklist from your browser. Note: Events previously synced to your Google Calendar will remain on your calendar.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#6F6B78]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteNotice(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="px-4 py-2 rounded-xl bg-[#C75A22] text-white text-xs font-bold shadow-xs"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
