import React, { useState } from 'react';
import {
  CheckSquare,
  Square,
  Calendar,
  Clock,
  AlertTriangle,
  ExternalLink,
  Search,
  Filter,
  CheckCircle2,
  Quote,
  Edit2,
  Check,
  X,
  ListTodo
} from 'lucide-react';
import { NoticeActionItem } from '../types/notice';

interface ActionItemsViewProps {
  actionItems: NoticeActionItem[];
  onToggleComplete: (noticeId: string, actionId: string) => void;
  onUpdateAction: (noticeId: string, actionId: string, updates: Partial<NoticeActionItem>) => void;
  onOpenNotice: (noticeId: string) => void;
  onOpenTasksSync?: (items?: NoticeActionItem[]) => void;
}

export const ActionItemsView: React.FC<ActionItemsViewProps> = ({
  actionItems,
  onToggleComplete,
  onUpdateAction,
  onOpenNotice,
  onOpenTasksSync,
}) => {
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'overdue' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDate, setEditDate] = useState('');

  const filteredItems = actionItems.filter((item) => {
    // Search query filter
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.noticeTitle || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filter === 'completed') return !!item.completed;
    if (filter === 'overdue') return !item.completed && item.isDeadlinePassed;
    if (filter === 'upcoming') return !item.completed && !item.isDeadlinePassed && !!item.dueDate;
    return true; // all
  });

  const startEdit = (item: NoticeActionItem) => {
    const key = `${item.noticeId || 'global'}_${item.id}`;
    setEditingKey(key);
    setEditTitle(item.title);
    setEditDate(item.dueDate || '');
  };

  const saveEdit = (item: NoticeActionItem) => {
    if (item.noticeId) {
      onUpdateAction(item.noticeId, item.id, {
        title: editTitle,
        dueDate: editDate || null,
      });
    }
    setEditingKey(null);
  };

  const completedCount = actionItems.filter((i) => i.completed).length;
  const overdueCount = actionItems.filter((i) => !i.completed && i.isDeadlinePassed).length;

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-10 h-10 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
                <CheckSquare className="w-5 h-5" />
              </span>
              <h1 className="text-2xl font-bold text-[#373444] tracking-tight">
                Consolidated Action Items
              </h1>
            </div>
            <p className="text-sm text-[#6F6B78]">
              All extracted tasks, requirements, and document preparations across your notices.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
            {onOpenTasksSync && (
              <button
                type="button"
                onClick={() => onOpenTasksSync(actionItems.filter((i) => !i.completed))}
                className="px-3.5 py-1.5 rounded-xl bg-[#DCEAF7] hover:bg-[#C9E0F5] text-[#1D4A73] border border-[#BDD8F1] shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
                title="Send active action items to Google Tasks"
              >
                <ListTodo className="w-3.5 h-3.5 text-[#2B6CB0]" />
                <span>Sync to Google Tasks</span>
              </button>
            )}
            <span className="px-3 py-1.5 rounded-xl bg-[#DDEBDD] text-[#254A30] border border-[#BDD6BD]">
              {completedCount} Completed
            </span>
            {overdueCount > 0 && (
              <span className="px-3 py-1.5 rounded-xl bg-[#F8E2D5] text-[#C75A22] border border-[#EAC2AE]">
                {overdueCount} Overdue
              </span>
            )}
          </div>
        </div>

        {/* Search & Status Filters */}
        <div className="mt-6 pt-4 border-t border-[#EAE4E8] flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-[#9C98A5] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search tasks or notices..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-2xl border border-[#EAE4E8] bg-[#FFF9F2]/50 text-xs text-[#373444] focus:outline-none focus:border-[#8273B8] focus:bg-white"
            />
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
            {[
              { id: 'all', label: `All (${actionItems.length})` },
              { id: 'upcoming', label: 'Upcoming' },
              { id: 'overdue', label: 'Overdue' },
              { id: 'completed', label: 'Completed' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  filter === tab.id
                    ? 'bg-[#8273B8] text-white shadow-xs'
                    : 'bg-[#FFF9F2] text-[#6F6B78] hover:bg-[#E8DFF5]/60 hover:text-[#373444]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Task List */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs space-y-4">
        {filteredItems.length > 0 ? (
          <div className="space-y-3">
            {filteredItems.map((item, idx) => {
              const key = `${item.noticeId || 'global'}_${item.id}_${idx}`;
              const isEditing = editingKey === key;

              return (
                <div
                  key={key}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                    item.completed
                      ? 'bg-[#DDEBDD]/40 border-[#BDD6BD]/70 opacity-85 shadow-2xs'
                      : 'bg-[#FFF9F2]/50 border-[#EAE4E8] hover:border-[#8273B8]/40 hover:bg-[#FFF9F2]'
                  }`}
                >
                  {isEditing ? (
                    <div className="space-y-3">
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="w-full p-2.5 rounded-xl border border-[#8273B8] bg-white text-sm font-semibold text-[#373444]"
                      />
                      <div className="flex items-center gap-2">
                        <input
                          type="date"
                          value={editDate}
                          onChange={(e) => setEditDate(e.target.value)}
                          className="p-2 rounded-xl border border-[#EAE4E8] bg-white text-xs text-[#373444]"
                        />
                        <button
                          type="button"
                          onClick={() => saveEdit(item)}
                          className="px-3 py-1.5 rounded-xl bg-[#8273B8] text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" /> Save
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingKey(null)}
                          className="px-3 py-1.5 rounded-xl bg-white border border-[#EAE4E8] text-[#6F6B78] text-xs font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" /> Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-start gap-3.5">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (item.noticeId) onToggleComplete(item.noticeId, item.id);
                        }}
                        className="mt-0.5 text-[#8273B8] hover:scale-110 active:scale-95 transition-transform focus:outline-none cursor-pointer p-0.5 shrink-0"
                        aria-label={item.completed ? `Mark "${item.title}" incomplete` : `Mark "${item.title}" complete`}
                      >
                        {item.completed ? (
                          <CheckSquare className="w-6 h-6 text-[#2F7343]" />
                        ) : (
                          <Square className="w-6 h-6 text-[#8273B8] hover:text-[#65559A]" />
                        )}
                      </button>

                      <div
                        className="flex-1 space-y-1.5 cursor-pointer select-none"
                        onClick={() => {
                          if (item.noticeId) onToggleComplete(item.noticeId, item.id);
                        }}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            if (item.noticeId) onToggleComplete(item.noticeId, item.id);
                          }
                        }}
                        aria-label={`Toggle ${item.title}`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <h3
                              className={`text-base font-bold transition-colors ${
                                item.completed
                                  ? 'line-through text-[#6F6B78]'
                                  : 'text-[#373444] hover:text-[#8273B8]'
                              }`}
                            >
                              {item.title}
                            </h3>
                            {item.noticeTitle && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (item.noticeId) onOpenNotice(item.noticeId);
                                }}
                                className="text-xs text-[#8273B8] hover:underline font-medium block cursor-pointer mt-0.5 text-left"
                              >
                                From notice: {item.noticeTitle}
                              </button>
                            )}
                          </div>

                          <div
                            className="flex flex-wrap items-center gap-1.5"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {item.dueDate ? (
                              <span
                                className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                                  item.isDeadlinePassed
                                    ? 'bg-[#F8E2D5] text-[#C75A22] border-[#EAC2AE]'
                                    : 'bg-[#DDEBDD] text-[#254A30] border-[#BDD6BD]'
                                }`}
                              >
                                <Calendar className="w-3.5 h-3.5" />
                                <span>
                                  {item.dueDate}
                                  {item.dueTime ? ` (${item.dueTime})` : ''}
                                  {item.isDeadlinePassed ? ' • Overdue' : ''}
                                </span>
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-[#FFF9F2] text-[#6F6B78] text-xs border border-[#EAE4E8]">
                                No deadline
                              </span>
                            )}

                            {item.isDateAmbiguous && (
                              <span
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#F8E2D5] text-[#C75A22] text-[11px] font-bold border border-[#EAC2AE]"
                                title="Check original notice to confirm year"
                              >
                                <AlertTriangle className="w-3 h-3" />
                                <span>Verify Year</span>
                              </span>
                            )}

                            {item.calendarEventLink && (
                              <a
                                href={item.calendarEventLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#DCEAF7] text-[#1D4A73] text-[11px] font-bold border border-[#BAD8F2] hover:underline cursor-pointer"
                              >
                                <span>In Calendar</span>
                                <ExternalLink className="w-2.5 h-2.5" />
                              </a>
                            )}

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                startEdit(item);
                              }}
                              className="p-1 rounded-lg text-[#6F6B78] hover:text-[#373444] hover:bg-white cursor-pointer transition-colors"
                              title="Edit task or deadline"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <p className="text-sm text-[#6F6B78] leading-relaxed">
                          {item.description}
                        </p>

                        {item.sourceQuote && (
                          <div className="pt-1.5 text-xs text-[#6F6B78] flex items-start gap-1">
                            <Quote className="w-3 h-3 text-[#8273B8] shrink-0 mt-0.5" />
                            <span className="italic line-clamp-2">"{item.sourceQuote}"</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-12 text-center text-[#6F6B78] space-y-2">
            <CheckCircle2 className="w-8 h-8 mx-auto text-[#4D7C5D]" />
            <p className="font-semibold text-sm text-[#373444]">No tasks matching your filter.</p>
            <p className="text-xs">
              {searchQuery ? 'Try clearing your search query.' : 'Upload or process a notice to extract actionable tasks.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
