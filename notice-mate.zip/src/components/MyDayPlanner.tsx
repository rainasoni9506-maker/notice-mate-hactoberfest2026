import React, { useState, useEffect } from 'react';
import {
  Sun,
  Calendar,
  Clock,
  CheckSquare,
  Square,
  AlertTriangle,
  Plus,
  RefreshCw,
  Sparkles,
  ArrowRight,
  Trash2,
  Edit2,
  Check,
  X,
  ListTodo,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Award
} from 'lucide-react';
import { DailyPlanItem, NoticeAnalysis, NoticeActionItem } from '../types/notice';

const STORAGE_KEY_MYDAY_COMPLETED = 'notice_mate_myday_completed_v1';
const STORAGE_KEY_MYDAY_CUSTOM = 'notice_mate_myday_custom_v1';

const getMyDayCompletedStore = (): Record<string, boolean> => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_MYDAY_COMPLETED);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

const saveMyDayCompletedStore = (store: Record<string, boolean>) => {
  try {
    localStorage.setItem(STORAGE_KEY_MYDAY_COMPLETED, JSON.stringify(store));
  } catch {}
};

const getMyDayCustomTasks = (): DailyPlanItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_MYDAY_CUSTOM);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

const saveMyDayCustomTasks = (tasks: DailyPlanItem[]) => {
  try {
    localStorage.setItem(STORAGE_KEY_MYDAY_CUSTOM, JSON.stringify(tasks));
  } catch {}
};

interface MyDayPlannerProps {
  savedNotices: NoticeAnalysis[];
  allActionItems: NoticeActionItem[];
  onToggleActionItem?: (noticeId: string, actionId: string) => void;
  onOpenGoogleTasksSync: () => void;
  onOpenNotice: (noticeId: string) => void;
}

export const MyDayPlanner: React.FC<MyDayPlannerProps> = ({
  savedNotices,
  allActionItems,
  onToggleActionItem,
  onOpenGoogleTasksSync,
  onOpenNotice,
}) => {
  // Day selection offset (0 = Today, 1 = Tomorrow, ..., up to 7 days)
  const [dayOffset, setDayOffset] = useState<number>(0);
  const [planItems, setPlanItems] = useState<DailyPlanItem[]>([]);
  const [customTitle, setCustomTitle] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  // Target date calculation
  const getTargetDate = (offset: number) => {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return d.toISOString().split('T')[0];
  };

  const targetDateStr = getTargetDate(dayOffset);
  const targetDateObj = new Date();
  targetDateObj.setDate(targetDateObj.getDate() + dayOffset);
  const formattedDayTitle =
    dayOffset === 0
      ? 'Today'
      : dayOffset === 1
      ? 'Tomorrow'
      : targetDateObj.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });

  // Generate / refresh daily plan from saved notices, timetables, datesheets, and user custom tasks
  const generatePlanFromDocuments = (offset: number) => {
    const targetDate = getTargetDate(offset);
    const completedStore = getMyDayCompletedStore();
    const customTasks = getMyDayCustomTasks();
    const newItems: DailyPlanItem[] = [];

    // 1. Custom User Tasks added for this specific date
    customTasks
      .filter((t) => t.date === targetDate)
      .forEach((custom) => {
        newItems.push({
          ...custom,
          completed: completedStore[custom.id] !== undefined ? completedStore[custom.id] : !!custom.completed,
        });
      });

    // 2. Fixed Calendar Events & Timetables on this date
    savedNotices.forEach((notice, noticeIdx) => {
      (notice.calendarEvents || []).forEach((ev, evIdx) => {
        if (ev.startDate === targetDate) {
          const stableId = `plan_ev_${notice.id}_${ev.id || evIdx}`;
          newItems.push({
            id: stableId,
            title: ev.title,
            description: ev.description || '',
            date: targetDate,
            time: ev.startTime || (ev.isAllDay ? 'All-Day' : undefined),
            type: ev.eventType === 'exam' ? 'fixed_event' : ev.eventType === 'class' ? 'fixed_event' : 'deadline',
            priority: ev.eventType === 'exam' ? 'high' : 'medium',
            sourceNoticeTitle: notice.title,
            sourceNoticeId: notice.id,
            completed: !!completedStore[stableId],
            isSuggested: false,
          });
        }
      });
    });

    // 3. Deadlines and Action Items due on or before this date
    allActionItems.forEach((action, actionIdx) => {
      const isDueToday = action.dueDate === targetDate;
      const isOverdue =
        offset === 0 &&
        action.dueDate &&
        action.dueDate < targetDate &&
        !action.completed;

      if (isDueToday || isOverdue) {
        const stableId = `plan_act_${action.noticeId || 'n'}_${action.id || actionIdx}`;
        // Preserve completed status: action.completed in noticeStorage takes priority, then completedStore
        const isCompleted =
          action.completed !== undefined ? action.completed : !!completedStore[stableId];

        newItems.push({
          id: stableId,
          title: isOverdue ? `[Overdue] ${action.title}` : action.title,
          description: action.description || '',
          date: targetDate,
          time: action.dueTime || undefined,
          type: 'deadline',
          priority: isOverdue ? 'high' : action.priority || 'medium',
          sourceNoticeTitle: action.noticeTitle,
          sourceNoticeId: action.noticeId,
          actionItemId: action.id,
          completed: isCompleted,
          isSuggested: false,
          googleTaskId: action.googleTaskId,
        });
      }
    });

    // 4. Smart AI Study / Preparation Suggestions before upcoming exams
    savedNotices.forEach((notice, noticeIdx) => {
      (notice.calendarEvents || []).forEach((ev, evIdx) => {
        if (ev.eventType === 'exam' && ev.startDate > targetDate) {
          const examD = new Date(ev.startDate);
          const currentD = new Date(targetDate);
          const diffDays = Math.round((examD.getTime() - currentD.getTime()) / (1000 * 60 * 60 * 24));

          if (diffDays > 0 && diffDays <= 4) {
            const stableId = `plan_prep_${notice.id}_${ev.id || evIdx}_${diffDays}`;
            newItems.push({
              id: stableId,
              title: `Prepare & Revise: ${ev.title} (in ${diffDays} day${diffDays > 1 ? 's' : ''})`,
              description: `Recommended study session prior to examination scheduled on ${ev.startDate}.`,
              date: targetDate,
              type: 'study_prep',
              priority: diffDays <= 2 ? 'high' : 'medium',
              sourceNoticeTitle: notice.title,
              sourceNoticeId: notice.id,
              completed: !!completedStore[stableId],
              isSuggested: true,
            });
          }
        }
      });
    });

    // 5. Conflict detection: find items with overlapping specific times
    const timeSlots: Record<string, string[]> = {};
    newItems.forEach((item) => {
      if (item.time && item.time !== 'All-Day') {
        if (!timeSlots[item.time]) timeSlots[item.time] = [];
        timeSlots[item.time].push(item.title);
      }
    });

    newItems.forEach((item) => {
      if (item.time && timeSlots[item.time] && timeSlots[item.time].length > 1) {
        item.hasConflict = true;
        item.conflictDetails = `Time clash at ${item.time}: multiple events scheduled simultaneously!`;
      }
    });

    return newItems;
  };

  // Load plan when dayOffset changes or notices/actions update
  useEffect(() => {
    const items = generatePlanFromDocuments(dayOffset);
    setPlanItems(items);
  }, [dayOffset, savedNotices, allActionItems]);

  const toggleItemComplete = (id: string) => {
    const target = planItems.find((item) => item.id === id);
    if (!target) return;

    const newCompleted = !target.completed;

    // 1. If linked to an action item in a notice, update noticeStorage via parent callback
    if (target.actionItemId && target.sourceNoticeId && onToggleActionItem) {
      onToggleActionItem(target.sourceNoticeId, target.actionItemId);
    }

    // 2. Persist in My Day completed store so regenerating or tab switching doesn't erase it
    const completedStore = getMyDayCompletedStore();
    completedStore[id] = newCompleted;
    saveMyDayCompletedStore(completedStore);

    // 3. If user custom task, update custom tasks store as well
    if (target.type === 'user_task') {
      const customTasks = getMyDayCustomTasks();
      const updatedCustom = customTasks.map((c) =>
        c.id === id ? { ...c, completed: newCompleted } : c
      );
      saveMyDayCustomTasks(updatedCustom);
    }

    // 4. Immediately update local state
    setPlanItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, completed: newCompleted } : item))
    );
  };

  const handlePostpone = (id: string) => {
    // Postpone task to tomorrow
    const tomorrowStr = getTargetDate(dayOffset + 1);
    const customTasks = getMyDayCustomTasks();
    const updatedCustom = customTasks.map((c) =>
      c.id === id ? { ...c, date: tomorrowStr } : c
    );
    saveMyDayCustomTasks(updatedCustom);
    setPlanItems((prev) => prev.filter((i) => i.id !== id));
  };

  const handleDeleteItem = (id: string) => {
    // Remove from custom tasks if applicable
    const customTasks = getMyDayCustomTasks();
    const updatedCustom = customTasks.filter((c) => c.id !== id);
    saveMyDayCustomTasks(updatedCustom);

    setPlanItems((prev) => prev.filter((i) => i.id !== id));
  };

  const handleAddCustomTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) return;

    const customItem: DailyPlanItem = {
      id: `plan_custom_${Date.now()}`,
      title: customTitle.trim(),
      description: 'Personal task added for the day',
      date: targetDateStr,
      type: 'user_task',
      priority: 'medium',
      completed: false,
      isSuggested: false,
    };

    // Save to persistent storage
    const customTasks = getMyDayCustomTasks();
    saveMyDayCustomTasks([customItem, ...customTasks]);

    setPlanItems((prev) => [customItem, ...prev]);
    setCustomTitle('');
    setShowAddForm(false);
  };

  const startEdit = (item: DailyPlanItem) => {
    setEditingId(item.id);
    setEditTitle(item.title);
  };

  const saveEdit = (id: string) => {
    setPlanItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, title: editTitle } : item))
    );

    const customTasks = getMyDayCustomTasks();
    const updatedCustom = customTasks.map((c) =>
      c.id === id ? { ...c, title: editTitle } : c
    );
    saveMyDayCustomTasks(updatedCustom);

    setEditingId(null);
  };

  const completedCount = planItems.filter((i) => i.completed).length;
  const hasConflicts = planItems.some((i) => i.hasConflict);

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-10 h-10 rounded-2xl bg-[#DDEBDD] text-[#254A30] flex items-center justify-center shadow-xs">
                <Sun className="w-5 h-5 text-[#345940]" />
              </span>
              <div>
                <h1 className="text-2xl font-bold text-[#373444] tracking-tight">
                  My Day — Smart Planner
                </h1>
                <p className="text-xs text-[#6F6B78]">
                  Automated daily study schedule combining timetables, exam prep, and notice deadlines.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenGoogleTasksSync}
              className="px-4 py-2.5 rounded-2xl bg-[#E8DFF5] hover:bg-[#D7C9EB] text-[#4F3F82] text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <ListTodo className="w-4 h-4 text-[#8273B8]" />
              <span>Sync with Google Tasks</span>
            </button>

            <button
              type="button"
              onClick={() => setPlanItems(generatePlanFromDocuments(dayOffset))}
              className="p-2.5 rounded-2xl bg-white border border-[#EAE4E8] text-[#6F6B78] hover:text-[#373444] hover:bg-[#FFF9F2] shadow-xs cursor-pointer"
              title="Regenerate suggested daily plan"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 7-Day Day Selector Bar */}
        <div className="mt-6 pt-4 border-t border-[#EAE4E8] flex items-center justify-between gap-2 overflow-x-auto pb-1">
          <div className="flex items-center gap-1.5">
            {[0, 1, 2, 3, 4, 5, 6, 7].map((offset) => {
              const d = new Date();
              d.setDate(d.getDate() + offset);
              const isSelected = dayOffset === offset;
              const label =
                offset === 0
                  ? 'Today'
                  : offset === 1
                  ? 'Tmrw'
                  : d.toLocaleDateString(undefined, { weekday: 'short' });
              const dateNum = d.getDate();

              return (
                <button
                  key={offset}
                  type="button"
                  onClick={() => setDayOffset(offset)}
                  className={`px-3 py-2 rounded-2xl text-center transition-all cursor-pointer min-w-[56px] ${
                    isSelected
                      ? 'bg-[#8273B8] text-white shadow-xs font-bold scale-105'
                      : 'bg-[#FFF9F2] text-[#6F6B78] hover:bg-[#E8DFF5]/50 hover:text-[#373444]'
                  }`}
                >
                  <div className="text-[10px] uppercase font-semibold">{label}</div>
                  <div className="text-sm font-bold">{dateNum}</div>
                </button>
              );
            })}
          </div>

          <div className="text-right text-xs font-semibold text-[#6F6B78] shrink-0 pl-2">
            <span>{completedCount} / {planItems.length} Done</span>
          </div>
        </div>
      </div>

      {/* Conflict Warning Banner if timetable or exam overlap exists */}
      {hasConflicts && (
        <div className="p-4 rounded-3xl bg-[#F8E2D5] border border-[#EAC2AE] flex items-start gap-3 text-xs sm:text-sm text-[#6E3C21]">
          <AlertTriangle className="w-5 h-5 text-[#C75A22] shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-bold">Schedule Conflict Detected!</p>
            <p className="text-xs">
              Multiple exams, classes, or meetings overlap at the same time on this day. Please check details below.
            </p>
          </div>
        </div>
      )}

      {/* Day Plan Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#373444]">
              {formattedDayTitle}’s Agenda
            </h2>
            <span className="text-xs font-normal text-[#9C98A5]">({targetDateStr})</span>
          </div>

          <button
            type="button"
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-3 py-1.5 rounded-xl bg-white border border-[#EAE4E8] hover:bg-[#FFF9F2] text-xs font-semibold text-[#373444] flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-[#8273B8]" />
            <span>Add Task</span>
          </button>
        </div>

        {/* Inline Add Task Form */}
        {showAddForm && (
          <form onSubmit={handleAddCustomTask} className="p-4 rounded-2xl bg-[#FFF9F2] border border-[#EAE4E8] space-y-2">
            <label className="text-xs font-bold text-[#373444]">Add to {formattedDayTitle}:</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder="e.g., Review Chemistry Chapter 4 or print lab manual..."
                className="flex-1 p-2 rounded-xl border border-[#EAE4E8] bg-white text-xs text-[#373444] focus:outline-none focus:border-[#8273B8]"
                autoFocus
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-[#8273B8] text-white text-xs font-bold cursor-pointer"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-medium text-[#6F6B78] cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {/* Plan Items List */}
        <div className="space-y-3 pt-2">
          {planItems.map((item, idx) => (
            <div
              key={`${item.id}_${idx}`}
              className={`p-4 rounded-2xl border transition-all ${
                item.completed
                  ? 'bg-[#DDEBDD]/40 border-[#BDD6BD]/70 opacity-85 shadow-2xs'
                  : item.hasConflict
                  ? 'bg-[#F8E2D5]/30 border-[#C75A22]'
                  : item.isSuggested
                  ? 'bg-[#E8DFF5]/20 border-[#D7C9EB]'
                  : 'bg-[#FFF9F2]/50 border-[#EAE4E8] hover:border-[#8273B8]/40 hover:bg-[#FFF9F2]'
              }`}
            >
              {editingId === item.id ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="flex-1 p-2 rounded-xl border border-[#8273B8] bg-white text-xs font-semibold text-[#373444]"
                  />
                  <button
                    type="button"
                    onClick={() => saveEdit(item.id)}
                    className="p-2 rounded-xl bg-[#8273B8] text-white text-xs font-bold cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingId(null)}
                    className="p-2 rounded-xl bg-white border border-[#EAE4E8] text-xs text-[#6F6B78] cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-start gap-3">
                  {/* Large Responsive Checkbox */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleItemComplete(item.id);
                    }}
                    className="mt-0.5 text-[#8273B8] hover:scale-110 active:scale-95 transition-transform cursor-pointer p-0.5 shrink-0 focus:outline-none"
                    aria-label={item.completed ? `Mark "${item.title}" incomplete` : `Mark "${item.title}" complete`}
                  >
                    {item.completed ? (
                      <CheckSquare className="w-5 h-5 text-[#2F7343]" />
                    ) : (
                      <Square className="w-5 h-5 text-[#8273B8] hover:text-[#65559A]" />
                    )}
                  </button>

                  {/* Task Content - Clickable text to toggle */}
                  <div
                    className="flex-1 space-y-1 cursor-pointer select-none"
                    onClick={() => toggleItemComplete(item.id)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        toggleItemComplete(item.id);
                      }
                    }}
                    aria-label={`Toggle ${item.title}`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-sm font-bold transition-colors ${
                            item.completed
                              ? 'line-through text-[#8E8A96]'
                              : 'text-[#373444] hover:text-[#8273B8]'
                          }`}
                        >
                          {item.title}
                        </span>

                        {item.isSuggested && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#E8DFF5] text-[#4F3F82] text-[10px] font-bold">
                            <Sparkles className="w-2.5 h-2.5" />
                            AI Suggested Prep
                          </span>
                        )}

                        {item.type === 'fixed_event' && (
                          <span className="px-2 py-0.5 rounded-full bg-[#DDEBDD] text-[#254A30] text-[10px] font-bold">
                            Fixed Event
                          </span>
                        )}
                      </div>

                      <div
                        className="flex items-center gap-1.5 text-xs"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {item.time && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-[#EAE4E8] text-[11px] font-medium text-[#373444]">
                            <Clock className="w-3 h-3 text-[#8273B8]" />
                            {item.time}
                          </span>
                        )}

                        {item.priority === 'high' && (
                          <span className="px-1.5 py-0.5 rounded-md bg-[#F8E2D5] text-[#C75A22] text-[10px] font-bold">
                            High Priority
                          </span>
                        )}

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            startEdit(item);
                          }}
                          className="p-1 text-[#9C98A5] hover:text-[#373444] rounded-lg cursor-pointer transition-colors"
                          title="Edit Title"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePostpone(item.id);
                          }}
                          className="p-1 text-[#9C98A5] hover:text-[#8273B8] rounded-lg cursor-pointer transition-colors"
                          title="Postpone to Tomorrow"
                        >
                          <ArrowRight className="w-3 h-3" />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteItem(item.id);
                          }}
                          className="p-1 text-[#9C98A5] hover:text-[#C75A22] rounded-lg cursor-pointer transition-colors"
                          title="Delete from Plan"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {item.description && (
                      <p className={`text-xs line-clamp-1 ${item.completed ? 'text-[#8E8A96]' : 'text-[#6F6B78]'}`}>
                        {item.description}
                      </p>
                    )}

                    {item.sourceNoticeTitle && item.sourceNoticeId && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenNotice(item.sourceNoticeId!);
                        }}
                        className="text-[11px] text-[#8273B8] hover:underline font-medium block cursor-pointer mt-0.5 text-left"
                      >
                        From notice: {item.sourceNoticeTitle}
                      </button>
                    )}

                    {item.hasConflict && (
                      <div className="p-2 rounded-xl bg-[#F8E2D5] text-[#C75A22] text-[11px] font-semibold flex items-center gap-1.5 mt-1">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>{item.conflictDetails}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}

          {planItems.length === 0 && (
            <div className="py-12 text-center text-[#6F6B78] space-y-2">
              <Sun className="w-8 h-8 text-[#E57A44] mx-auto opacity-70" />
              <p className="text-sm font-semibold text-[#373444]">Nothing scheduled for {formattedDayTitle}!</p>
              <p className="text-xs max-w-sm mx-auto">
                No exam dates, classes, or notice deadlines fall on this day. You can add a personal task above or upload a datesheet!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
