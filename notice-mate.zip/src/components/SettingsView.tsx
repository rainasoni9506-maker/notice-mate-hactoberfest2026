import React, { useState } from 'react';
import { Settings, Volume2, Globe, Eye, Calendar, ShieldCheck, Trash2, CheckCircle2, LogOut } from 'lucide-react';
import { AppSettings } from '../types/notice';
import { User } from 'firebase/auth';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  user: User | null;
  onConnectCalendar: () => void;
  onDisconnectCalendar: () => void;
  onClearAllData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  user,
  onConnectCalendar,
  onDisconnectCalendar,
  onClearAllData,
}) => {
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const handleLanguageChange = (lang: 'en' | 'hi') => {
    onUpdateSettings({ ...settings, preferredLanguage: lang });
  };

  const handleFontSizeChange = (size: 'normal' | 'large' | 'extralarge') => {
    onUpdateSettings({ ...settings, fontSize: size });
  };

  const handleVoiceChange = (voice: 'Kore' | 'Zephyr' | 'Puck' | 'browser') => {
    onUpdateSettings({ ...settings, ttsVoice: voice });
  };

  const handleSpeedChange = (speed: number) => {
    onUpdateSettings({ ...settings, ttsSpeed: speed });
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs">
        <div className="flex items-center gap-3">
          <span className="w-10 h-10 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
            <Settings className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-2xl font-bold text-[#373444] tracking-tight">
              Settings & Preferences
            </h1>
            <p className="text-xs text-[#6F6B78]">
              Personalize language, text sizing, speech preferences, and calendar connection.
            </p>
          </div>
        </div>
      </div>

      {/* Language Section */}
      <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-4">
        <div className="flex items-center gap-2 font-bold text-base text-[#373444]">
          <Globe className="w-5 h-5 text-[#8273B8]" />
          <span>Preferred Language</span>
        </div>
        <p className="text-xs text-[#6F6B78]">
          Choose the default language for simplified notice explanations and summaries.
        </p>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => handleLanguageChange('en')}
            className={`p-3.5 rounded-2xl border text-sm font-bold text-center transition-all ${
              settings.preferredLanguage === 'en'
                ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444] shadow-xs'
                : 'bg-[#FFF9F2]/50 border-[#EAE4E8] text-[#6F6B78] hover:bg-[#FFF9F2]'
            }`}
          >
            Simple English
          </button>
          <button
            type="button"
            onClick={() => handleLanguageChange('hi')}
            className={`p-3.5 rounded-2xl border text-sm font-bold text-center transition-all ${
              settings.preferredLanguage === 'hi'
                ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444] shadow-xs'
                : 'bg-[#FFF9F2]/50 border-[#EAE4E8] text-[#6F6B78] hover:bg-[#FFF9F2]'
            }`}
          >
            हिन्दी (Hindi)
          </button>
        </div>
      </div>

      {/* Accessibility & Visual Sizing */}
      <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-4">
        <div className="flex items-center gap-2 font-bold text-base text-[#373444]">
          <Eye className="w-5 h-5 text-[#8273B8]" />
          <span>Accessibility & Text Size</span>
        </div>
        <p className="text-xs text-[#6F6B78]">
          Scale the reading typography to improve readability for notices and checklists.
        </p>
        <div className="grid grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => handleFontSizeChange('normal')}
            className={`p-3 rounded-2xl border text-center transition-all ${
              settings.fontSize === 'normal'
                ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444] font-bold shadow-xs'
                : 'bg-[#FFF9F2]/50 border-[#EAE4E8] text-[#6F6B78]'
            }`}
          >
            <div className="text-sm font-medium">Standard</div>
            <div className="text-xs text-[#9C98A5]">16px</div>
          </button>

          <button
            type="button"
            onClick={() => handleFontSizeChange('large')}
            className={`p-3 rounded-2xl border text-center transition-all ${
              settings.fontSize === 'large'
                ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444] font-bold shadow-xs'
                : 'bg-[#FFF9F2]/50 border-[#EAE4E8] text-[#6F6B78]'
            }`}
          >
            <div className="text-base font-semibold">Large</div>
            <div className="text-xs text-[#9C98A5]">18px</div>
          </button>

          <button
            type="button"
            onClick={() => handleFontSizeChange('extralarge')}
            className={`p-3 rounded-2xl border text-center transition-all ${
              settings.fontSize === 'extralarge'
                ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444] font-bold shadow-xs'
                : 'bg-[#FFF9F2]/50 border-[#EAE4E8] text-[#6F6B78]'
            }`}
          >
            <div className="text-lg font-bold">Extra Large</div>
            <div className="text-xs text-[#9C98A5]">20px</div>
          </button>
        </div>
      </div>

      {/* Voice & Speech Preferences */}
      <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-4">
        <div className="flex items-center gap-2 font-bold text-base text-[#373444]">
          <Volume2 className="w-5 h-5 text-[#8273B8]" />
          <span>Speech & Text-to-Speech</span>
        </div>
        <p className="text-xs text-[#6F6B78]">
          Notice Mate uses Gemini AI neural audio synthesis for warm, natural reading aloud.
        </p>

        <div className="space-y-3">
          <label className="text-xs font-semibold text-[#6F6B78] block">Voice Persona</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'Kore', label: 'Kore (Warm)' },
              { id: 'Zephyr', label: 'Zephyr (Calm)' },
              { id: 'Puck', label: 'Puck (Bright)' },
              { id: 'browser', label: 'Browser Voice' },
            ].map((v) => (
              <button
                key={v.id}
                type="button"
                onClick={() => handleVoiceChange(v.id as any)}
                className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  settings.ttsVoice === v.id
                    ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444]'
                    : 'bg-white border-[#EAE4E8] text-[#6F6B78]'
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>

          <label className="text-xs font-semibold text-[#6F6B78] block pt-2">Speech Speed</label>
          <div className="flex items-center gap-2">
            {[0.8, 1, 1.25].map((speed) => (
              <button
                key={speed}
                type="button"
                onClick={() => handleSpeedChange(speed)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                  settings.ttsSpeed === speed
                    ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444]'
                    : 'bg-white border-[#EAE4E8] text-[#6F6B78]'
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Google Calendar Section */}
      <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-4">
        <div className="flex items-center gap-2 font-bold text-base text-[#373444]">
          <Calendar className="w-5 h-5 text-[#8273B8]" />
          <span>Google Calendar Connection</span>
        </div>
        <p className="text-xs text-[#6F6B78]">
          Notice Mate uses Google OAuth 2.0 with minimal required permissions to add verified notice dates directly into your Google Calendar.
        </p>

        {user ? (
          <div className="p-4 rounded-2xl bg-[#DDEBDD]/50 border border-[#BDD6BD] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <p className="text-xs font-bold text-[#254A30] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#2F7343]" />
                Connected Account
              </p>
              <p className="text-sm font-semibold text-[#1F3D27]">{user.email}</p>
            </div>
            <button
              type="button"
              onClick={onDisconnectCalendar}
              className="px-4 py-2 rounded-xl bg-white border border-[#BDD6BD] text-xs font-semibold text-[#6E3C21] hover:bg-[#F8E2D5]/30 flex items-center gap-1.5 self-start sm:self-auto"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Disconnect</span>
            </button>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-[#FFF9F2] border border-[#EAE4E8] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="text-sm font-bold text-[#373444]">No Calendar Connected</p>
              <p className="text-xs text-[#6F6B78]">Connect to sync deadlines and receive automated reminders.</p>
            </div>
            <button
              type="button"
              onClick={onConnectCalendar}
              className="px-4 py-2 rounded-xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs font-bold shadow-xs flex items-center gap-2 self-start sm:self-auto"
            >
              <span>Connect Google Calendar</span>
            </button>
          </div>
        )}
      </div>

      {/* Privacy and Data Clearance */}
      <div className="bg-white rounded-3xl p-6 border border-[#EAE4E8] shadow-xs space-y-4">
        <div className="flex items-center gap-2 font-bold text-base text-[#373444]">
          <ShieldCheck className="w-5 h-5 text-[#4D7C5D]" />
          <span>Privacy & Data Management</span>
        </div>
        <p className="text-xs text-[#6F6B78] leading-relaxed">
          Notice Mate is designed for privacy. Your notices, action items, and reading history are stored entirely locally in your browser storage. We never sell your data or retain uploaded documents.
        </p>

        <div className="pt-2">
          <button
            type="button"
            onClick={() => setShowClearConfirm(true)}
            className="px-4 py-2.5 rounded-2xl bg-[#F8E2D5]/50 border border-[#EAC2AE] text-xs font-bold text-[#C75A22] hover:bg-[#F8E2D5] flex items-center gap-2"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear All Local Notice History</span>
          </button>
        </div>
      </div>

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#EAE4E8] shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-[#373444]">Clear All Saved Notices?</h3>
            <p className="text-xs text-[#6F6B78]">
              This will erase all saved notice summaries and checklists from this browser. This cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#6F6B78]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearAllData();
                  setShowClearConfirm(false);
                }}
                className="px-4 py-2 rounded-xl bg-[#C75A22] text-white text-xs font-bold shadow-xs"
              >
                Erase Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
