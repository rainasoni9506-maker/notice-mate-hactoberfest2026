import React, { useState } from 'react';
import { CheckSquare, Square, Calendar, Clock, AlertTriangle, Edit2, Check, X, Quote, ExternalLink, CalendarPlus, ListTodo } from 'lucide-react';
import { NoticeActionItem } from '../types/notice';

interface ActionChecklistProps {
  actionItems: NoticeActionItem[];
  onToggleComplete: (id: string) => void;
  onUpdateAction: (id: string, updates: Partial<NoticeActionItem>) => void;
  onOpenCalendarReview: () => void;
  onOpenTasksSync?: () => void;
}

export const ActionChecklist: React.FC<ActionChecklistProps> = ({
  actionItems,
  onToggleComplete,
  onUpdateAction,
  onOpenCalendarReview,
  onOpenTasksSync,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDate, setEditDate] = useState('');

  const startEdit = (item: NoticeActionItem) => {
    setEditingId(item.id);
    setEditTitle(item.title);
    setEditDate(item.dueDate || '');
  };

  const saveEdit = (id: string) => {
    onUpdateAction(id, {
      title: editTitle,
      dueDate: editDate || null,
    });
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const completedCount = actionItems.filter((i) => i.completed).length;

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs space-y-6">
      {/* Header with Stats and Calendar Action Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#373444] tracking-tight flex items-center gap-2">
            <span>Your Next Steps</span>
            <span className="px-2.5 py-0.5 rounded-full bg-[#DDEBDD] text-[#254A30] text-xs font-bold">
              {completedCount} of {actionItems.length} Done
            </span>
          </h2>
          <p className="text-xs text-[#6F6B78]">
            Check tasks off as you complete them, or add all confirmed dates to Google Calendar.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          {onOpenTasksSync && (
            <button
              type="button"
              onClick={onOpenTasksSync}
              className="px-3.5 py-2.5 rounded-2xl bg-[#DCEAF7] hover:bg-[#C9E0F5] text-[#1D4A73] text-xs sm:text-sm font-semibold border border-[#BDD8F1] shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
              title="Add tasks to your Google Tasks lists"
            >
              <ListTodo className="w-4 h-4 text-[#2B6CB0]" />
              <span>Sync to Google Tasks</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenCalendarReview}
            className="px-4 py-2.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs sm:text-sm font-semibold shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <CalendarPlus className="w-4 h-4" />
            <span>Add Dates to Google Calendar</span>
          </button>
        </div>
      </div>

      {/* Action Items List */}
      <div className="space-y-3">
        {actionItems.map((item, idx) => (
          <div
            key={`${item.id}_${idx}`}
            className={`p-4 sm:p-5 rounded-2xl border transition-all ${
              item.completed
                ? 'bg-[#DDEBDD]/40 border-[#BDD6BD]/70 opacity-85 shadow-2xs'
                : 'bg-[#FFF9F2]/50 border-[#EAE4E8] hover:border-[#8273B8]/40 hover:bg-[#FFF9F2]'
            }`}
          >
            {editingId === item.id ? (
              /* Inline Edit Mode */
              <div className="space-y-3">
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-[#8273B8] bg-white text-sm font-semibold text-[#373444] focus:outline-none"
                  placeholder="Task title"
                />
                <div className="flex items-center gap-2">
                  <input
                    type="date"
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    className="p-2 rounded-xl border border-[#EAE4E8] bg-white text-xs text-[#373444] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => saveEdit(item.id)}
                    className="px-3 py-1.5 rounded-xl bg-[#8273B8] text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" /> Save
                  </button>
                  <button
                    type="button"
                    onClick={cancelEdit}
                    className="px-3 py-1.5 rounded-xl bg-white border border-[#EAE4E8] text-[#6F6B78] text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" /> Cancel
                  </button>
                </div>
              </div>
            ) : (
              /* Normal View Mode */
              <div className="flex items-start gap-3.5">
                {/* Large Responsive Checkbox */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleComplete(item.id);
                  }}
                  className="mt-0.5 text-[#8273B8] hover:scale-110 active:scale-95 transition-transform focus:outline-none cursor-pointer p-0.5 shrink-0"
                  aria-label={item.completed ? `Mark "${item.title}" incomplete` : `Mark "${item.title}" complete`}
                >
                  {item.completed ? (
                    <CheckSquare className="w-6 h-6 text-[#2F7343]" />
                  ) : (
                    <Square className="w-6 h-6 text-[#8273B8] hover:text-[#65559A]" />
                  )}
                </button>

                {/* Content - Clickable task text to toggle */}
                <div
                  className="flex-1 space-y-1.5 cursor-pointer select-none"
                  onClick={() => onToggleComplete(item.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      onToggleComplete(item.id);
                    }
                  }}
                  aria-label={`Toggle ${item.title}`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3
                      className={`text-base font-bold transition-colors ${
                        item.completed
                          ? 'line-through text-[#6F6B78]'
                          : 'text-[#373444] hover:text-[#8273B8]'
                      }`}
                    >
                      {item.title}
                    </h3>

                    {/* Deadline & Sync Status Badges */}
                    <div
                      className="flex flex-wrap items-center gap-1.5"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {item.dueDate ? (
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                            item.isDeadlinePassed
                              ? 'bg-[#F8E2D5] text-[#C75A22] border-[#EAC2AE]'
                              : 'bg-[#DDEBDD] text-[#254A30] border-[#BDD6BD]'
                          }`}
                        >
                          <Calendar className="w-3.5 h-3.5" />
                          <span>
                            {item.dueDate}
                            {item.dueTime ? ` at ${item.dueTime}` : ''}
                            {item.isDeadlinePassed ? ' (Passed)' : ''}
                          </span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-[#FFF9F2] text-[#6F6B78] text-xs border border-[#EAE4E8]">
                          No specific date
                        </span>
                      )}

                      {/* Ambiguity Flag */}
                      {item.isDateAmbiguous && (
                        <span
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#F8E2D5] text-[#C75A22] text-[11px] font-bold border border-[#EAC2AE]"
                          title={item.ambiguityReason || 'Year unstated in notice'}
                        >
                          <AlertTriangle className="w-3 h-3" />
                          <span>Verify Year</span>
                        </span>
                      )}

                      {/* Calendar Sync Status */}
                      {item.calendarEventLink && (
                        <a
                          href={item.calendarEventLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#DCEAF7] text-[#1D4A73] text-[11px] font-bold border border-[#BAD8F2] hover:underline cursor-pointer"
                        >
                          <span>In Calendar</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      )}

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          startEdit(item);
                        }}
                        className="p-1 rounded-lg text-[#6F6B78] hover:text-[#373444] hover:bg-white cursor-pointer transition-colors"
                        title="Edit task or date"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <p
                    className={`text-sm leading-relaxed ${
                      item.completed ? 'text-[#8E8A96]' : 'text-[#6F6B78]'
                    }`}
                  >
                    {item.description}
                  </p>

                  {/* Supporting Source Sentence */}
                  {item.sourceQuote && (
                    <div className="pt-1.5 text-xs text-[#6F6B78] flex items-start gap-1">
                      <Quote className="w-3 h-3 text-[#8273B8] shrink-0 mt-0.5" />
                      <span className="italic line-clamp-2">"{item.sourceQuote}"</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
