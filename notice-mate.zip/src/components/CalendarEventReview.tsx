import React, { useState, useEffect } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ExternalLink,
  Bell,
  RefreshCw,
  X,
  Check,
  ShieldCheck,
  CalendarPlus,
  AlertCircle
} from 'lucide-react';
import { NoticeEventCandidate, NoticeAnalysis } from '../types/notice';
import { createCalendarEvent, checkForDuplicateEvent, GoogleCalendarEventResponse } from '../services/calendarService';
import { User } from 'firebase/auth';

interface CalendarEventReviewProps {
  analysis: NoticeAnalysis;
  user: User | null;
  onConnectCalendar: () => void;
  onClose: () => void;
  onEventsSynced: (updatedCandidates: NoticeEventCandidate[]) => void;
}

export const CalendarEventReview: React.FC<CalendarEventReviewProps> = ({
  analysis,
  user,
  onConnectCalendar,
  onClose,
  onEventsSynced,
}) => {
  const [candidates, setCandidates] = useState<NoticeEventCandidate[]>(
    analysis.calendarEvents.map((evt) => ({
      ...evt,
      selected: evt.selected !== undefined ? evt.selected : true,
      reminders: evt.reminders || [1440, 60], // 1 day before, 1 hour before
    }))
  );

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [syncProgress, setSyncProgress] = useState<{ current: number; total: number } | null>(null);
  const [syncResults, setSyncResults] = useState<{
    succeeded: Array<{ title: string; htmlLink: string }>;
    failed: Array<{ title: string; error: string }>;
  } | null>(null);

  // Mandatory confirmation dialog state for mutating Workspace data
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [duplicateWarnings, setDuplicateWarnings] = useState<Record<string, string>>({});

  // Check for duplicates when opening
  useEffect(() => {
    if (user) {
      candidates.forEach(async (cand) => {
        const check = await checkForDuplicateEvent(cand);
        if (check.isDuplicate && check.existingEvent) {
          setDuplicateWarnings((prev) => ({
            ...prev,
            [cand.id]: `Similar event found: "${check.existingEvent?.summary}" on ${cand.startDate}`,
          }));
        }
      });
    }
  }, [user]);

  const toggleSelect = (id: string) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, selected: !c.selected } : c))
    );
  };

  const updateCandidate = (id: string, updates: Partial<NoticeEventCandidate>) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const selectedCandidates = candidates.filter((c) => c.selected);

  // Initiates the creation flow by showing explicit confirmation dialog
  const handleProceedClick = () => {
    if (selectedCandidates.length === 0) return;
    setShowConfirmModal(true);
  };

  // Executes actual calendar event creation via Google Calendar API
  const handleConfirmAddEvents = async () => {
    setShowConfirmModal(false);
    setIsSubmitting(true);
    setSyncProgress({ current: 0, total: selectedCandidates.length });

    const succeeded: Array<{ title: string; htmlLink: string }> = [];
    const failed: Array<{ title: string; error: string }> = [];

    const updatedList = [...candidates];

    for (let i = 0; i < selectedCandidates.length; i++) {
      const cand = selectedCandidates[i];
      setSyncProgress({ current: i + 1, total: selectedCandidates.length });

      try {
        const result: GoogleCalendarEventResponse = await createCalendarEvent(cand, analysis.title);
        succeeded.push({ title: cand.title, htmlLink: result.htmlLink });

        // Update candidate in state
        const idx = updatedList.findIndex((item) => item.id === cand.id);
        if (idx >= 0) {
          updatedList[idx] = {
            ...updatedList[idx],
            syncedEventId: result.id,
            calendarHtmlLink: result.htmlLink,
            syncStatus: 'synced',
          };
        }
      } catch (err: any) {
        console.error('Failed to create event:', cand.title, err);
        failed.push({ title: cand.title, error: err.message || 'API error' });

        const idx = updatedList.findIndex((item) => item.id === cand.id);
        if (idx >= 0) {
          updatedList[idx] = {
            ...updatedList[idx],
            syncStatus: 'error',
            errorMessage: err.message,
          };
        }
      }
    }

    setCandidates(updatedList);
    setSyncResults({ succeeded, failed });
    setIsSubmitting(false);
    onEventsSynced(updatedList);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full border border-[#EAE4E8] shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-6 border-b border-[#EAE4E8] bg-[#FFF9F2] flex items-center justify-between">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
                <Calendar className="w-4 h-4" />
              </span>
              <h2 className="text-xl font-bold text-[#373444]">
                Review Google Calendar Events
              </h2>
            </div>
            <p className="text-xs text-[#6F6B78]">
              Verify and customize the dates Notice Mate extracted before adding them to your schedule.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#6F6B78] hover:bg-white transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Calendar Connection Banner */}
          {!user ? (
            <div className="p-4 rounded-2xl bg-[#DCEAF7]/50 border border-[#BAD8F2] flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="space-y-1 text-center sm:text-left">
                <p className="text-sm font-bold text-[#1D4A73]">
                  Connect your Google Calendar
                </p>
                <p className="text-xs text-[#2C6294]">
                  Sign in with Google to allow Notice Mate to schedule your reviewed dates.
                </p>
              </div>
              <button
                type="button"
                onClick={onConnectCalendar}
                className="px-4 py-2.5 rounded-2xl bg-white border border-[#BAD8F2] text-xs font-semibold text-[#1D4A73] hover:bg-white/80 shadow-xs flex items-center gap-2 shrink-0"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Connect Google Calendar</span>
              </button>
            </div>
          ) : (
            <div className="p-3 rounded-2xl bg-[#DDEBDD]/50 border border-[#BDD6BD] flex items-center justify-between text-xs text-[#254A30]">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#2F7343]" />
                Connected as <strong>{user.email}</strong>
              </span>
              <span className="text-[11px] text-[#4D7C5D]">Calendar sync ready</span>
            </div>
          )}

          {/* Sync Results Banner if sync completed */}
          {syncResults && (
            <div className="space-y-3">
              {syncResults.succeeded.length > 0 && (
                <div className="p-4 rounded-2xl bg-[#DDEBDD] border border-[#BDD6BD] text-[#254A30] space-y-2">
                  <div className="flex items-center gap-2 font-bold text-sm">
                    <CheckCircle2 className="w-5 h-5 text-[#2F7343]" />
                    <span>Your selected events were added successfully!</span>
                  </div>
                  <ul className="text-xs space-y-1 pl-7">
                    {syncResults.succeeded.map((item, idx) => (
                      <li key={idx} className="flex items-center justify-between">
                        <span>• {item.title}</span>
                        {item.htmlLink && (
                          <a
                            href={item.htmlLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-bold underline flex items-center gap-1 hover:text-[#193220]"
                          >
                            Open in Google Calendar
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {syncResults.failed.length > 0 && (
                <div className="p-4 rounded-2xl bg-[#F8E2D5] border border-[#EAC2AE] text-[#6E3C21] space-y-1">
                  <div className="flex items-center gap-2 font-bold text-sm">
                    <AlertCircle className="w-5 h-5 text-[#C75A22]" />
                    <span>Some events could not be added:</span>
                  </div>
                  <ul className="text-xs space-y-1 pl-7">
                    {syncResults.failed.map((item, idx) => (
                      <li key={idx}>• {item.title}: {item.error}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Event Candidates List */}
          <div className="space-y-4">
            {candidates.map((cand, idx) => (
              <div
                key={`${cand.id}_${idx}`}
                className={`p-4 rounded-2xl border transition-all ${
                  cand.selected
                    ? 'bg-white border-[#8273B8]/60 shadow-xs'
                    : 'bg-[#FFF9F2]/60 border-[#EAE4E8] opacity-60'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Selection Checkbox */}
                  <input
                    type="checkbox"
                    checked={cand.selected}
                    onChange={() => toggleSelect(cand.id)}
                    className="mt-1 w-5 h-5 rounded text-[#8273B8] focus:ring-[#8273B8] cursor-pointer"
                    id={`cand-${cand.id}`}
                  />

                  <div className="flex-1 space-y-3">
                    {/* Event Title Edit */}
                    <div className="space-y-1">
                      <label htmlFor={`title-${cand.id}`} className="text-xs font-semibold text-[#6F6B78]">
                        Event Title
                      </label>
                      <input
                        id={`title-${cand.id}`}
                        type="text"
                        value={cand.title}
                        onChange={(e) => updateCandidate(cand.id, { title: e.target.value })}
                        className="w-full p-2 rounded-xl border border-[#EAE4E8] bg-[#FFF9F2]/30 text-sm font-bold text-[#373444] focus:outline-none focus:border-[#8273B8]"
                      />
                    </div>

                    {/* Date and Time Fields */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-[#6F6B78]">Date</label>
                        <input
                          type="date"
                          value={cand.startDate}
                          onChange={(e) =>
                            updateCandidate(cand.id, {
                              startDate: e.target.value,
                              endDate: e.target.value,
                            })
                          }
                          className="w-full p-2 rounded-xl border border-[#EAE4E8] bg-white text-xs font-semibold text-[#373444]"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-[#6F6B78]">Time</label>
                        <input
                          type="time"
                          disabled={cand.isAllDay}
                          value={cand.startTime || ''}
                          onChange={(e) => updateCandidate(cand.id, { startTime: e.target.value })}
                          className="w-full p-2 rounded-xl border border-[#EAE4E8] bg-white text-xs font-semibold text-[#373444] disabled:opacity-40"
                        />
                      </div>

                      <div className="flex items-end pb-1.5">
                        <label className="flex items-center gap-2 text-xs font-semibold text-[#373444] cursor-pointer">
                          <input
                            type="checkbox"
                            checked={cand.isAllDay}
                            onChange={(e) => updateCandidate(cand.id, { isAllDay: e.target.checked })}
                            className="rounded text-[#8273B8]"
                          />
                          <span>All-day event</span>
                        </label>
                      </div>
                    </div>

                    {/* Ambiguity or Duplicate Warnings */}
                    {cand.isAmbiguous && (
                      <div className="p-2.5 rounded-xl bg-[#F8E2D5] border border-[#EAC2AE] flex items-center gap-2 text-xs text-[#6E3C21]">
                        <AlertTriangle className="w-4 h-4 text-[#C75A22] shrink-0" />
                        <span>
                          <strong>Needs verification:</strong> {cand.ambiguityNote || 'Year was not explicitly stated in notice.'}
                        </span>
                      </div>
                    )}

                    {duplicateWarnings[cand.id] && (
                      <div className="p-2.5 rounded-xl bg-[#F8E2D5] border border-[#EAC2AE] flex items-center gap-2 text-xs text-[#6E3C21]">
                        <AlertCircle className="w-4 h-4 text-[#C75A22] shrink-0" />
                        <span>{duplicateWarnings[cand.id]}</span>
                      </div>
                    )}

                    {/* Verbatim Source Quote */}
                    {cand.sourceQuote && (
                      <p className="text-xs text-[#6F6B78] italic">
                        Source quote: "{cand.sourceQuote}"
                      </p>
                    )}

                    {/* Reminders Selector */}
                    <div className="flex items-center gap-2 text-xs text-[#6F6B78]">
                      <Bell className="w-3.5 h-3.5 text-[#8273B8]" />
                      <span>Reminders:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { label: 'On day', minutes: 0 },
                          { label: '1 day before', minutes: 1440 },
                          { label: '3 days before', minutes: 4320 },
                          { label: '1 week before', minutes: 10080 },
                        ].map((opt) => {
                          const active = cand.reminders?.includes(opt.minutes);
                          return (
                            <button
                              key={opt.minutes}
                              type="button"
                              onClick={() => {
                                const current = cand.reminders || [];
                                const next = active
                                  ? current.filter((m) => m !== opt.minutes)
                                  : [...current, opt.minutes];
                                updateCandidate(cand.id, { reminders: next });
                              }}
                              className={`px-2 py-0.5 rounded-lg border text-[11px] font-medium transition-colors ${
                                active
                                  ? 'bg-[#E8DFF5] border-[#8273B8] text-[#373444]'
                                  : 'bg-white border-[#EAE4E8] text-[#9C98A5]'
                              }`}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-5 border-t border-[#EAE4E8] bg-[#FFF9F2] flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-xs text-[#6F6B78]">
            {selectedCandidates.length} of {candidates.length} events selected
          </span>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl bg-white border border-[#EAE4E8] text-sm font-semibold text-[#6F6B78] hover:bg-[#FFF9F2]"
            >
              Cancel
            </button>

            {user ? (
              <button
                type="button"
                onClick={handleProceedClick}
                disabled={isSubmitting || selectedCandidates.length === 0}
                className="px-6 py-2.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] active:scale-[0.99] disabled:opacity-50 text-white text-sm font-semibold shadow-xs flex items-center justify-center gap-2 w-full sm:w-auto"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>
                      Adding {syncProgress?.current || 0}/{syncProgress?.total || 0}...
                    </span>
                  </>
                ) : (
                  <>
                    <CalendarPlus className="w-4 h-4" />
                    <span>Add Selected Dates to Google Calendar</span>
                  </>
                )}
              </button>
            ) : (
              <button
                type="button"
                onClick={onConnectCalendar}
                className="px-6 py-2.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-sm font-semibold shadow-xs flex items-center justify-center gap-2 w-full sm:w-auto"
              >
                <span>Connect Calendar to Proceed</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mandatory Explicit Confirmation Dialog before creating Workspace events */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#EAE4E8] shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center">
                <CalendarPlus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#373444]">
                  Confirm Calendar Addition
                </h3>
                <p className="text-xs text-[#6F6B78]">
                  Workspace Authorization Check
                </p>
              </div>
            </div>

            <p className="text-sm text-[#373444] leading-relaxed">
              Are you sure you want to add <strong>{selectedCandidates.length}</strong> event(s) to your Google Calendar (<strong>{user?.email}</strong>)?
            </p>

            <div className="max-h-36 overflow-y-auto p-3 rounded-xl bg-[#FFF9F2] border border-[#EAE4E8] text-xs space-y-1">
              {selectedCandidates.map((c, i) => (
                <div key={c.id} className="text-[#373444]">
                  • <strong>{c.title}</strong> on {c.startDate} {c.isAllDay ? '(All-day)' : `at ${c.startTime}`}
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#6F6B78] hover:bg-[#FFF9F2]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmAddEvents}
                className="px-5 py-2 rounded-xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs font-bold shadow-xs flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Confirm & Add</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
