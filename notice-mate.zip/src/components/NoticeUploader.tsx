import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  Camera,
  AlertCircle,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  RefreshCw,
  Zap,
  RotateCcw
} from 'lucide-react';
import { SAMPLE_NOTICES, SampleNoticePreset } from '../data/sampleNotices';
import { NoticeAnalysis } from '../types/notice';
import { optimizeDocumentFile, OptimizedFileResult } from '../utils/imageOptimizer';

interface NoticeUploaderProps {
  onAnalyze: (payload: { fileData?: string; mimeType?: string; text?: string; fileName?: string }) => Promise<void>;
  onLoadSample: (sample: NoticeAnalysis) => void;
  isProcessing: boolean;
  processingStage: 1 | 2 | 3;
  externalError?: string | null;
  onRetry?: () => void;
}

export const NoticeUploader: React.FC<NoticeUploaderProps> = ({
  onAnalyze,
  onLoadSample,
  isProcessing,
  processingStage,
  externalError,
  onRetry,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [optimizedInfo, setOptimizedInfo] = useState<OptimizedFileResult | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [pastedText, setPastedText] = useState('');
  const [mode, setMode] = useState<'upload' | 'paste'>('upload');
  const [localError, setLocalError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const displayError = externalError || localError;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const processAndSetFile = async (file: File) => {
    setLocalError(null);
    const validExtensions = ['.pdf', '.docx', '.txt', '.png', '.jpg', '.jpeg', '.webp'];
    const hasValidExt = validExtensions.some((ext) => file.name.toLowerCase().endsWith(ext));
    const isAcceptedMime =
      file.type.startsWith('image/') ||
      file.type.includes('pdf') ||
      file.type.includes('word') ||
      file.type.includes('text') ||
      hasValidExt;

    if (!isAcceptedMime) {
      setLocalError('Unsupported file format. Please upload a PDF, Word (.docx), Text (.txt), or image (JPG/PNG).');
      return;
    }

    if (file.size > 30 * 1024 * 1024) {
      setLocalError('File size exceeds 30 MB. Please choose a smaller photo or document.');
      return;
    }

    setSelectedFile(file);
    setIsOptimizing(true);

    try {
      // Pre-optimize image resolution on client-side for fast network transfer & instant Gemini ingestion
      const optimized = await optimizeDocumentFile(file);
      setOptimizedInfo(optimized);
    } catch (err: any) {
      console.warn('Optimization error, will read directly on submit:', err);
      setOptimizedInfo(null);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processAndSetFile(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    if (isProcessing) return; // Prevent duplicate clicks
    setLocalError(null);

    if (mode === 'upload') {
      if (!selectedFile) {
        setLocalError('Please select a PDF or image file first.');
        return;
      }

      try {
        let fileData = optimizedInfo?.base64Data;
        let mimeType = optimizedInfo?.mimeType;

        // If not already pre-optimized, optimize now
        if (!fileData) {
          setIsOptimizing(true);
          const res = await optimizeDocumentFile(selectedFile);
          fileData = res.base64Data;
          mimeType = res.mimeType;
          setIsOptimizing(false);
        }

        if (!fileData) {
          throw new Error('Unable to read document file. Please select a readable image or PDF.');
        }

        await onAnalyze({
          fileData,
          mimeType: mimeType || 'image/jpeg',
          fileName: selectedFile.name,
        });
      } catch (err: any) {
        setIsOptimizing(false);
        setLocalError(err.message || 'Failed to process document file.');
      }
    } else {
      if (!pastedText.trim() || pastedText.trim().length < 15) {
        setLocalError('Please paste the complete text of the notice (at least a few words).');
        return;
      }
      await onAnalyze({
        text: pastedText.trim(),
        fileName: 'Pasted Notice Text',
      });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Welcome Heading */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E8DFF5] text-[#4F3F82] text-xs font-semibold">
          <Zap className="w-3.5 h-3.5 text-[#8273B8]" />
          <span>Fast AI Notice-to-Action Engine</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-[#373444] tracking-tight">
          Let's make your notices easier.
        </h1>
        <p className="text-base text-[#6F6B78] max-w-2xl mx-auto">
          Upload any college notice, exam circular, scholarship announcement, or government circular.
          We'll extract facts, simplify them, and help you sync confirmed deadlines to Google Calendar in seconds.
        </p>
      </div>

      {/* Main Upload Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-sm">
        {/* Toggle between Upload File and Paste Text */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <button
            type="button"
            disabled={isProcessing}
            onClick={() => {
              setMode('upload');
              setLocalError(null);
            }}
            className={`px-4 py-2 rounded-2xl text-sm font-semibold transition-all flex items-center gap-2 ${
              mode === 'upload'
                ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                : 'text-[#6F6B78] hover:text-[#373444] bg-[#FFF9F2]'
            } disabled:opacity-60`}
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload Document (PDF / Word / Text / Image)</span>
          </button>

          <button
            type="button"
            disabled={isProcessing}
            onClick={() => {
              setMode('paste');
              setLocalError(null);
            }}
            className={`px-4 py-2 rounded-2xl text-sm font-semibold transition-all flex items-center gap-2 ${
              mode === 'paste'
                ? 'bg-[#E8DFF5] text-[#373444] shadow-xs'
                : 'text-[#6F6B78] hover:text-[#373444] bg-[#FFF9F2]'
            } disabled:opacity-60`}
          >
            <FileText className="w-4 h-4" />
            <span>Paste text instead</span>
          </button>
        </div>

        {/* Upload Mode Area */}
        {mode === 'upload' ? (
          <div>
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-3xl p-8 sm:p-10 text-center transition-all cursor-pointer ${
                dragActive
                  ? 'border-[#8273B8] bg-[#E8DFF5]/30 scale-[1.005]'
                  : selectedFile
                  ? 'border-[#4D7C5D] bg-[#DDEBDD]/30'
                  : 'border-[#EAE4E8] bg-[#FFF9F2]/60 hover:border-[#8273B8]/60 hover:bg-[#FFF9F2]'
              }`}
              onClick={() => {
                if (!isProcessing) fileInputRef.current?.click();
              }}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.txt,image/png,image/jpeg,image/jpg,image/webp"
                onChange={handleFileChange}
                disabled={isProcessing}
                className="hidden"
                aria-label="Upload PDF, DOCX, TXT or image notice"
              />

              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileChange}
                disabled={isProcessing}
                className="hidden"
                aria-label="Capture photo of notice"
              />

              <div className="flex flex-col items-center justify-center space-y-3">
                <div className="w-16 h-16 rounded-3xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center shadow-xs">
                  {selectedFile ? (
                    <CheckCircle2 className="w-8 h-8 text-[#4D7C5D]" />
                  ) : (
                    <UploadCloud className="w-8 h-8" />
                  )}
                </div>

                {selectedFile ? (
                  <div className="space-y-1">
                    <p className="font-semibold text-lg text-[#373444]">{selectedFile.name}</p>
                    <div className="flex items-center justify-center gap-2 text-xs text-[#6F6B78]">
                      <span>{(selectedFile.size / (1024 * 1024)).toFixed(2)} MB</span>
                      {optimizedInfo && optimizedInfo.isImage && (
                        <span className="px-2 py-0.5 rounded-full bg-[#DDEBDD] text-[#254A30] font-semibold text-[11px]">
                          Optimized: {(optimizedInfo.optimizedSize / 1024).toFixed(0)} KB for fast AI processing
                        </span>
                      )}
                    </div>
                    {!isProcessing && (
                      <span className="inline-block mt-2 text-xs font-semibold text-[#8273B8] underline">
                        Click to choose a different file
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="space-y-1">
                    <p className="text-base sm:text-lg font-semibold text-[#373444]">
                      Drag and drop your academic notice, datesheet or timetable here, or browse
                    </p>
                    <p className="text-xs sm:text-sm text-[#6F6B78]">
                      Supports PDF, Word (.docx), Text (.txt), and photos of notices (JPG, PNG)
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    disabled={isProcessing}
                    onClick={(e) => {
                      e.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                    className="px-4 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#373444] hover:bg-[#FFF9F2] shadow-xs disabled:opacity-50"
                  >
                    Choose a file
                  </button>

                  <button
                    type="button"
                    disabled={isProcessing}
                    onClick={(e) => {
                      e.stopPropagation();
                      cameraInputRef.current?.click();
                    }}
                    className="px-4 py-2 rounded-xl bg-white border border-[#EAE4E8] text-xs font-semibold text-[#373444] hover:bg-[#FFF9F2] shadow-xs flex items-center gap-1.5 disabled:opacity-50"
                    title="Take photo of printed notice with camera"
                  >
                    <Camera className="w-3.5 h-3.5 text-[#6F6B78]" />
                    <span>Take Photo</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Paste Text Mode Area */
          <div className="space-y-3">
            <label htmlFor="notice-text-input" className="block text-sm font-semibold text-[#373444]">
              Paste the notice or circular text below:
            </label>
            <textarea
              id="notice-text-input"
              rows={8}
              value={pastedText}
              disabled={isProcessing}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder="Paste exam notice, university circular, scholarship details, or admission announcement text here..."
              className="w-full p-4 rounded-2xl border border-[#EAE4E8] bg-[#FFF9F2]/40 text-[#373444] placeholder-[#9C98A5] focus:outline-none focus:ring-2 focus:ring-[#8273B8] focus:bg-white text-sm font-mono leading-relaxed resize-y disabled:opacity-60"
            />
            <div className="flex justify-between text-xs text-[#6F6B78]">
              <span>Direct text input processes in ~2-4 seconds.</span>
              <span>{pastedText.length} characters</span>
            </div>
          </div>
        )}

        {/* Error Alert with Actionable Retry Button */}
        {displayError && !isProcessing && (
          <div className="mt-4 p-4 rounded-2xl bg-[#F8E2D5] border border-[#EAC2AE] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-sm text-[#6E3C21]">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 shrink-0 text-[#C75A22] mt-0.5" />
              <div>
                <p className="font-bold text-xs uppercase tracking-wider text-[#C75A22]">Processing Alert</p>
                <p className="font-medium text-xs sm:text-sm">{displayError}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
              {onRetry && (
                <button
                  type="button"
                  onClick={onRetry}
                  className="px-3.5 py-1.5 rounded-xl bg-white border border-[#EAC2AE] text-xs font-bold text-[#6E3C21] hover:bg-[#FFF9F2] shadow-xs flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retry</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setLocalError(null)}
                className="text-xs text-[#6E3C21] underline hover:no-underline"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Action Button & Processing Indicator */}
        <div className="mt-6 pt-4 border-t border-[#EAE4E8] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#6F6B78]">
            Notice Mate protects your privacy. Uploaded documents are analyzed solely for you.
          </p>

          <button
            type="button"
            onClick={handleSubmit}
            disabled={
              isProcessing ||
              isOptimizing ||
              (mode === 'upload' && !selectedFile) ||
              (mode === 'paste' && !pastedText.trim())
            }
            className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none text-white font-semibold text-base shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isProcessing || isOptimizing ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>
                  {isOptimizing
                    ? 'Optimizing document...'
                    : processingStage === 1
                    ? 'Reading document...'
                    : processingStage === 2
                    ? 'Extracting key details...'
                    : 'Preparing summary...'}
                </span>
              </>
            ) : (
              <>
                <span>Understand My Notice</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>

        {/* Friendly 3-Stage Progress Indicator */}
        {isProcessing && (
          <div className="mt-6 p-6 rounded-2xl bg-[#FFF9F2] border border-[#EAE4E8] space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between text-xs font-semibold text-[#6F6B78]">
              <span>Fast AI Document Processing</span>
              <span>
                {processingStage === 1 ? 'Reading' : processingStage === 2 ? 'Extracting' : 'Finalizing'} (Stage {processingStage} of 3)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div
                className={`p-3 rounded-xl border flex items-center gap-2.5 transition-colors ${
                  processingStage >= 1
                    ? 'bg-[#DDEBDD] border-[#BDD6BD] text-[#254A30]'
                    : 'bg-white border-[#EAE4E8] text-[#9C98A5]'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                    processingStage >= 1 ? 'bg-[#2F7343] text-white' : 'bg-[#EAE4E8] text-[#6F6B78]'
                  }`}
                >
                  1
                </div>
                <span className="text-xs font-semibold">Reading document</span>
              </div>

              <div
                className={`p-3 rounded-xl border flex items-center gap-2.5 transition-colors ${
                  processingStage >= 2
                    ? 'bg-[#DDEBDD] border-[#BDD6BD] text-[#254A30]'
                    : 'bg-white border-[#EAE4E8] text-[#9C98A5]'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                    processingStage >= 2 ? 'bg-[#2F7343] text-white' : 'bg-[#EAE4E8] text-[#6F6B78]'
                  }`}
                >
                  2
                </div>
                <span className="text-xs font-semibold">Extracting key details</span>
              </div>

              <div
                className={`p-3 rounded-xl border flex items-center gap-2.5 transition-colors ${
                  processingStage >= 3
                    ? 'bg-[#DDEBDD] border-[#BDD6BD] text-[#254A30]'
                    : 'bg-white border-[#EAE4E8] text-[#9C98A5]'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                    processingStage >= 3 ? 'bg-[#2F7343] text-white' : 'bg-[#EAE4E8] text-[#6F6B78]'
                  }`}
                >
                  3
                </div>
                <span className="text-xs font-semibold">Preparing summary</span>
              </div>
            </div>

            <p className="text-xs text-center text-[#6F6B78] italic">
              "Extracting key deadlines, instructions, and confirmed dates..."
            </p>
          </div>
        )}
      </div>

      {/* Quick Test with Sample Notices */}
      <div className="bg-[#FFF9F2] rounded-3xl p-5 border border-[#EAE4E8]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div>
            <h3 className="text-sm font-bold text-[#373444] flex items-center gap-1.5">
              <span>Quick Test: Try a Realistic Sample Notice</span>
              <span className="px-2 py-0.5 rounded-full bg-[#E8DFF5] text-[#4F3F82] text-[10px] font-semibold">
                Instant
              </span>
            </h3>
            <p className="text-xs text-[#6F6B78]">
              Don't have a document handy? Click a pre-configured sample to test the full Notice-to-Action journey immediately:
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {SAMPLE_NOTICES.map((sample: SampleNoticePreset) => (
            <button
              key={sample.id}
              type="button"
              disabled={isProcessing}
              onClick={() => onLoadSample(sample.preparsedAnalysis)}
              className="text-left p-4 rounded-2xl bg-white border border-[#EAE4E8] hover:border-[#8273B8] hover:shadow-sm transition-all group disabled:opacity-50"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="inline-block px-2 py-0.5 rounded-md bg-[#FFF9F2] text-[#8273B8] font-bold text-[11px] mb-1">
                    {sample.tag}
                  </span>
                  <h4 className="text-sm font-bold text-[#373444] group-hover:text-[#8273B8] transition-colors">
                    {sample.name}
                  </h4>
                  <p className="text-xs text-[#6F6B78] line-clamp-2 mt-1">
                    {sample.description}
                  </p>
                </div>
                <div className="w-8 h-8 rounded-xl bg-[#E8DFF5] text-[#8273B8] flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
