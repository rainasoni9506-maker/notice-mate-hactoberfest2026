import React, { useState, useEffect } from 'react';
import { Volume2, Play, Pause, Square, FastForward, X } from 'lucide-react';
import { speechService, SpeechStatus } from '../services/speechService';

export const AudioBar: React.FC = () => {
  const [status, setStatus] = useState<SpeechStatus>('idle');
  const [speed, setSpeed] = useState<number>(1);

  useEffect(() => {
    const unsub = speechService.onStatusChange(setStatus);
    return () => unsub();
  }, []);

  if (status === 'idle') return null;

  const handleToggle = () => {
    if (status === 'playing') {
      speechService.pause();
    } else if (status === 'paused') {
      speechService.resume();
    }
  };

  const handleStop = () => {
    speechService.stop();
  };

  const handleSpeedCycle = () => {
    const nextSpeed = speed === 1 ? 1.25 : speed === 1.25 ? 0.8 : 1;
    setSpeed(nextSpeed);
    speechService.setSpeed(nextSpeed);
  };

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4 animate-in slide-in-from-bottom duration-300">
      <div className="bg-[#373444] text-white rounded-3xl p-3.5 shadow-2xl border border-white/10 flex items-center justify-between gap-3 backdrop-blur-md">
        <div className="flex items-center gap-2.5 pl-1.5">
          <div className="w-8 h-8 rounded-xl bg-[#8273B8] flex items-center justify-center shrink-0">
            <Volume2 className="w-4 h-4 text-white animate-pulse" />
          </div>
          <div>
            <p className="text-xs font-bold leading-none">
              {status === 'loading'
                ? 'Synthesizing voice...'
                : status === 'playing'
                ? 'Reading aloud'
                : 'Paused'}
            </p>
            <p className="text-[10px] text-white/70 mt-0.5">Notice Mate Accessibility</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleSpeedCycle}
            className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-bold text-white transition-colors"
            title="Speech rate"
          >
            {speed}x
          </button>

          <button
            type="button"
            onClick={handleToggle}
            disabled={status === 'loading'}
            className="w-8 h-8 rounded-full bg-white text-[#373444] hover:bg-white/90 flex items-center justify-center transition-transform active:scale-95 disabled:opacity-50"
            aria-label={status === 'playing' ? 'Pause speech' : 'Resume speech'}
          >
            {status === 'playing' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 pl-0.5" />}
          </button>

          <button
            type="button"
            onClick={handleStop}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            title="Stop audio"
            aria-label="Stop audio"
          >
            <Square className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleStop}
            className="p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10 transition-colors"
            title="Close player"
            aria-label="Close audio player"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
