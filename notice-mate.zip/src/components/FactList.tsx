import React, { useState } from 'react';
import { Quote, Tag, CheckCircle2, Clock, FileText, AlertCircle, Shield, CreditCard, Award } from 'lucide-react';
import { NoticeFact } from '../types/notice';

interface FactListProps {
  facts: NoticeFact[];
}

export const FactList: React.FC<FactListProps> = ({ facts }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Facts' },
    { id: 'deadline', label: 'Deadlines' },
    { id: 'exam', label: 'Exams' },
    { id: 'fee', label: 'Fees' },
    { id: 'document', label: 'Documents' },
    { id: 'eligibility', label: 'Eligibility' },
  ];

  const filteredFacts = facts.filter((f) => {
    if (activeCategory === 'all') return true;
    return f.category.toLowerCase().includes(activeCategory);
  });

  const getCategoryIcon = (category: string) => {
    const cat = category.toLowerCase();
    if (cat.includes('deadline')) return <Clock className="w-4 h-4 text-[#E57A44]" />;
    if (cat.includes('exam')) return <Award className="w-4 h-4 text-[#8273B8]" />;
    if (cat.includes('fee')) return <CreditCard className="w-4 h-4 text-[#345940]" />;
    if (cat.includes('document')) return <FileText className="w-4 h-4 text-[#2C6294]" />;
    if (cat.includes('eligibility')) return <Shield className="w-4 h-4 text-[#C75A22]" />;
    return <Tag className="w-4 h-4 text-[#6F6B78]" />;
  };

  const getCategoryBadgeClass = (category: string) => {
    const cat = category.toLowerCase();
    if (cat.includes('deadline')) return 'bg-[#F8E2D5] text-[#6E3C21] border-[#EAC2AE]';
    if (cat.includes('exam')) return 'bg-[#E8DFF5] text-[#4F3F82] border-[#D7C9EB]';
    if (cat.includes('fee')) return 'bg-[#DDEBDD] text-[#254A30] border-[#BDD6BD]';
    if (cat.includes('document')) return 'bg-[#DCEAF7] text-[#1D4A73] border-[#BAD8F2]';
    if (cat.includes('eligibility')) return 'bg-[#F8E2D5] text-[#6E3C21] border-[#EAC2AE]';
    return 'bg-[#FFF9F2] text-[#6F6B78] border-[#EAE4E8]';
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#EAE4E8] shadow-xs space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-[#373444] tracking-tight flex items-center gap-2">
            <span>Verified Facts & Source Evidence</span>
            <span className="px-2.5 py-0.5 rounded-full bg-[#E8DFF5] text-[#4F3F82] text-xs font-bold">
              {facts.length} Extracted
            </span>
          </h2>
          <p className="text-xs text-[#6F6B78]">
            Every extracted fact is linked to its exact sentence in the notice for verification.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeCategory === cat.id
                  ? 'bg-[#8273B8] text-white shadow-xs'
                  : 'bg-[#FFF9F2] text-[#6F6B78] hover:bg-[#E8DFF5]/60 hover:text-[#373444]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Facts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredFacts.length > 0 ? (
          filteredFacts.map((fact) => (
            <div
              key={fact.id}
              className="p-5 rounded-2xl bg-[#FFF9F2]/50 border border-[#EAE4E8] hover:border-[#8273B8]/40 hover:bg-[#FFF9F2] transition-all space-y-3 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${getCategoryBadgeClass(
                      fact.category
                    )}`}
                  >
                    {getCategoryIcon(fact.category)}
                    <span className="capitalize">{fact.category}</span>
                  </span>

                  {fact.importance === 'high' && (
                    <span className="px-2 py-0.5 rounded-md bg-[#F8E2D5] text-[#C75A22] text-[10px] font-bold uppercase tracking-wider">
                      Critical
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-[#373444] leading-snug">
                  {fact.title}
                </h3>
                <p className="text-sm text-[#6F6B78] leading-relaxed">
                  {fact.description}
                </p>
              </div>

              {/* Verbatim Source Quote Callout */}
              <div className="pt-2 border-t border-[#EAE4E8]/80 text-xs">
                <div className="flex items-start gap-1.5 p-2.5 rounded-xl bg-white border border-[#EAE4E8] text-[#373444] italic">
                  <Quote className="w-3.5 h-3.5 text-[#8273B8] shrink-0 mt-0.5" />
                  <span className="line-clamp-3">"{fact.sourceQuote}"</span>
                </div>
                {fact.pageOrSection && (
                  <p className="text-[11px] text-[#9C98A5] mt-1 text-right">
                    Source: {fact.pageOrSection}
                  </p>
                )}
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-2 text-center py-8 text-sm text-[#6F6B78] italic">
            No facts found in the "{activeCategory}" category.
          </div>
        )}
      </div>
    </div>
  );
};
