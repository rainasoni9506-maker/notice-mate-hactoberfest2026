/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { User } from 'firebase/auth';
import { Header } from './components/Header';
import { NoticeUploader } from './components/NoticeUploader';
import { NoticeSummary } from './components/NoticeSummary';
import { FactList } from './components/FactList';
import { ActionChecklist } from './components/ActionChecklist';
import { CalendarEventReview } from './components/CalendarEventReview';
import { CalendarView } from './components/CalendarView';
import { MyNoticesView } from './components/MyNoticesView';
import { ActionItemsView } from './components/ActionItemsView';
import { SettingsView } from './components/SettingsView';
import { MyDayPlanner } from './components/MyDayPlanner';
import { AIChatPanel } from './components/AIChatPanel';
import { GoogleTasksSyncModal } from './components/GoogleTasksSyncModal';
import { AudioBar } from './components/AudioBar';
import {
  initAuth,
  googleSignIn,
  logout,
} from './services/firebaseAuth';
import {
  getNotices,
  saveNotice,
  deleteNotice,
  updateActionItem,
  getAllActionItems,
  getSettings,
  saveSettings,
  clearAllData,
} from './services/noticeStorage';
import { NoticeAnalysis, NoticeEventCandidate, NoticeActionItem, AppSettings } from './types/notice';
import { SAMPLE_NOTICES } from './data/sampleNotices';
import { ArrowLeft, CalendarPlus, CheckCircle2, Bot } from 'lucide-react';

interface AnalysisPayload {
  fileData?: string;
  mimeType?: string;
  text?: string;
  fileName?: string;
}

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'notices' | 'actions' | 'calendar' | 'myday' | 'settings'>('home');
  const [user, setUser] = useState<User | null>(null);
  const [settings, setSettingsState] = useState<AppSettings>(getSettings());
  const [savedNotices, setSavedNotices] = useState<NoticeAnalysis[]>([]);
  const [activeAnalysis, setActiveAnalysis] = useState<NoticeAnalysis | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStage, setProcessingStage] = useState<1 | 2 | 3>(1);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [lastPayload, setLastPayload] = useState<AnalysisPayload | null>(null);
  const [showCalendarReview, setShowCalendarReview] = useState(false);
  const [globalNotification, setGlobalNotification] = useState<string | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isTasksSyncModalOpen, setIsTasksSyncModalOpen] = useState(false);
  const [tasksSyncItems, setTasksSyncItems] = useState<NoticeActionItem[]>([]);

  // In-memory session cache for instant repeat results
  const sessionCacheRef = useRef<Map<string, NoticeAnalysis>>(new Map());

  // Load notices and settings from storage on startup
  useEffect(() => {
    const list = getNotices();
    setSavedNotices(list);

    // Pre-populate with sample notice if first time opening
    if (list.length === 0 && SAMPLE_NOTICES.length > 0) {
      saveNotice(SAMPLE_NOTICES[0].preparsedAnalysis);
      setSavedNotices([SAMPLE_NOTICES[0].preparsedAnalysis]);
    }
  }, []);

  // Initialize Firebase Auth listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (authenticatedUser) => {
        setUser(authenticatedUser);
      },
      () => {
        setUser(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettingsState(newSettings);
    saveSettings(newSettings);
  };

  const handleConnectCalendar = async () => {
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setGlobalNotification('Google Calendar connected successfully!');
        setTimeout(() => setGlobalNotification(null), 4000);
      }
    } catch (err: any) {
      console.error('Google Sign-in failed:', err);
      setGlobalNotification(`Sign-in failed: ${err.message || 'Cancelled'}`);
      setTimeout(() => setGlobalNotification(null), 5000);
    }
  };

  const handleDisconnectCalendar = async () => {
    try {
      await logout();
      setUser(null);
      setGlobalNotification('Google Calendar disconnected.');
      setTimeout(() => setGlobalNotification(null), 3000);
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  // Analyze Notice via backend endpoint with fast session caching and timeout safety
  const handleAnalyzeNotice = async (payload: AnalysisPayload) => {
    if (isProcessing) return; // Prevent duplicate requests

    setIsProcessing(true);
    setAnalysisError(null);
    setLastPayload(payload);
    setProcessingStage(1);

    // Compute session cache key
    const cacheKey = payload.text
      ? `text:${payload.text.trim()}`
      : `file:${payload.fileName}:${payload.mimeType}:${payload.fileData?.slice(0, 500)}:${payload.fileData?.length}`;

    if (sessionCacheRef.current.has(cacheKey)) {
      const cached = sessionCacheRef.current.get(cacheKey)!;
      setActiveAnalysis(cached);
      setIsProcessing(false);
      setCurrentTab('home');
      setGlobalNotification('Loaded instant analysis from session cache.');
      setTimeout(() => setGlobalNotification(null), 3500);
      return;
    }

    // Set up responsive progress staging
    const timer1 = setTimeout(() => setProcessingStage(2), 1200);
    const timer2 = setTimeout(() => setProcessingStage(3), 2600);

    // 65-second request abort timeout to accommodate complex OCR & multimodal documents safely
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 65000);

    try {
      const response = await fetch('/api/gemini/analyze-notice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileData: payload.fileData,
          mimeType: payload.mimeType,
          text: payload.text,
          noticeName: payload.fileName,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const result = await response.json();
      if (!result.data) {
        throw new Error('Analysis completed but returned empty structured data.');
      }

      const newAnalysis: NoticeAnalysis = {
        ...result.data,
        id: `notice_${Date.now()}`,
        fileName: payload.fileName || 'Uploaded Notice',
        rawInputType: payload.fileData ? (payload.mimeType?.includes('pdf') ? 'pdf' : 'image') : 'text',
        createdAt: new Date().toISOString(),
      };

      // Cache result in memory for current session
      sessionCacheRef.current.set(cacheKey, newAnalysis);

      // Save to localStorage
      saveNotice(newAnalysis);
      setSavedNotices(getNotices());
      setActiveAnalysis(newAnalysis);
      setCurrentTab('home');

      setGlobalNotification('Notice analyzed successfully! Review your action plan below.');
      setTimeout(() => setGlobalNotification(null), 4000);
    } catch (err: any) {
      console.error('Failed to analyze notice:', err);
      const isAbort = err.name === 'AbortError';
      const msg = isAbort
        ? 'Analysis took longer than usual or was interrupted. Please click Retry.'
        : err.message || 'Failed to process notice with AI. Please retry.';
      setAnalysisError(msg);
    } finally {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timeoutId);
      setIsProcessing(false);
      setProcessingStage(1);
    }
  };

  const handleRetry = () => {
    if (lastPayload) {
      handleAnalyzeNotice(lastPayload);
    }
  };

  const handleLoadSample = (sample: NoticeAnalysis) => {
    setActiveAnalysis(sample);
    saveNotice(sample);
    setSavedNotices(getNotices());
    setGlobalNotification(`Loaded sample: "${sample.title}"`);
    setTimeout(() => setGlobalNotification(null), 4000);
  };

  const handleToggleComplete = (actionId: string) => {
    if (!activeAnalysis) return;
    const target = activeAnalysis.actionItems.find((a) => a.id === actionId);
    if (target) {
      const newStatus = !target.completed;
      updateActionItem(activeAnalysis.id, actionId, { completed: newStatus });
      // Update active state
      const updatedList = activeAnalysis.actionItems.map((a) =>
        a.id === actionId ? { ...a, completed: newStatus } : a
      );
      const updatedAnalysis = { ...activeAnalysis, actionItems: updatedList };
      setActiveAnalysis(updatedAnalysis);
      saveNotice(updatedAnalysis);
      setSavedNotices(getNotices());
    }
  };

  // Synchronized toggle for any notice across ActionItemsView, MyDay, and chat
  const handleToggleNoticeAction = (noticeId: string, actionId: string) => {
    const notices = getNotices();
    const notice = notices.find((n) => n.id === noticeId);
    if (!notice) return;
    const target = (notice.actionItems || []).find((a) => a.id === actionId);
    if (!target) return;

    const newStatus = !target.completed;
    target.completed = newStatus;
    saveNotice(notice);

    const updatedNotices = getNotices();
    setSavedNotices(updatedNotices);

    // Keep activeAnalysis in sync if it is the notice being updated
    if (activeAnalysis && activeAnalysis.id === noticeId) {
      setActiveAnalysis({
        ...activeAnalysis,
        actionItems: (activeAnalysis.actionItems || []).map((a) =>
          a.id === actionId ? { ...a, completed: newStatus } : a
        ),
      });
    }
  };

  const handleUpdateAction = (actionId: string, updates: any) => {
    if (!activeAnalysis) return;
    updateActionItem(activeAnalysis.id, actionId, updates);
    const updatedList = activeAnalysis.actionItems.map((a) =>
      a.id === actionId ? { ...a, ...updates } : a
    );
    const updatedAnalysis = { ...activeAnalysis, actionItems: updatedList };
    setActiveAnalysis(updatedAnalysis);
    saveNotice(updatedAnalysis);
    setSavedNotices(getNotices());
  };

  const handleEventsSynced = (updatedCandidates: NoticeEventCandidate[]) => {
    if (!activeAnalysis) return;
    const updatedAnalysis: NoticeAnalysis = {
      ...activeAnalysis,
      calendarEvents: updatedCandidates,
    };
    saveNotice(updatedAnalysis);
    setActiveAnalysis(updatedAnalysis);
    setSavedNotices(getNotices());
  };

  const handleDeleteNotice = (id: string) => {
    deleteNotice(id);
    setSavedNotices(getNotices());
    if (activeAnalysis?.id === id) {
      setActiveAnalysis(null);
    }
  };

  const handleClearAllData = () => {
    clearAllData();
    sessionCacheRef.current.clear();
    setSavedNotices([]);
    setActiveAnalysis(null);
    setGlobalNotification('All local notice data was cleared.');
    setTimeout(() => setGlobalNotification(null), 3000);
  };

  const handleOpenTasksSync = (items?: NoticeActionItem[]) => {
    if (items && items.length > 0) {
      setTasksSyncItems(items);
    } else if (activeAnalysis && activeAnalysis.actionItems.length > 0) {
      setTasksSyncItems(activeAnalysis.actionItems);
    } else {
      setTasksSyncItems(allActions.filter((a) => !a.completed));
    }
    setIsTasksSyncModalOpen(true);
  };

  const handleTasksSynced = (syncedIds: string[]) => {
    setGlobalNotification(`Successfully synced ${syncedIds.length} item(s) to Google Tasks!`);
    setTimeout(() => setGlobalNotification(null), 4000);
  };

  const allActions = getAllActionItems();
  const pendingActions = allActions.filter((a) => !a.completed);

  // Dynamic font sizing wrapper class
  const fontSizeClass =
    settings.fontSize === 'extralarge'
      ? 'text-lg [&_p]:text-base [&_h2]:text-2xl [&_h3]:text-xl'
      : settings.fontSize === 'large'
      ? 'text-base [&_p]:text-[15px] [&_h2]:text-xl [&_h3]:text-lg'
      : 'text-sm';

  return (
    <div className={`min-h-screen bg-[#FFF9F2] text-[#373444] flex flex-col font-sans ${fontSizeClass}`}>
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab)}
        user={user}
        onConnectCalendar={handleConnectCalendar}
        onDisconnectCalendar={handleDisconnectCalendar}
        savedNoticesCount={savedNotices.length}
        pendingActionsCount={pendingActions.length}
        fontSize={settings.fontSize}
        onFontSizeChange={(size) => handleUpdateSettings({ ...settings, fontSize: size })}
        isChatOpen={isChatOpen}
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
      />

      {/* Global Toast Notification */}
      {globalNotification && (
        <div className="bg-[#DDEBDD] border-b border-[#BDD6BD] text-[#254A30] text-xs font-semibold py-2.5 px-4 text-center transition-all animate-in fade-in flex items-center justify-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-[#2F7343]" />
          <span>{globalNotification}</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {currentTab === 'home' && (
          <>
            {activeAnalysis ? (
              /* Notice Analysis Active View */
              <div className="space-y-6">
                {/* Back to Upload and Action Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-[#EAE4E8]">
                  <button
                    type="button"
                    onClick={() => setActiveAnalysis(null)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#8273B8] hover:text-[#7263A8] transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Upload or Analyze Another Notice</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowCalendarReview(true)}
                      className="px-4 py-2 rounded-xl bg-[#8273B8] hover:bg-[#7263A8] text-white text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <CalendarPlus className="w-3.5 h-3.5" />
                      <span>Review & Add to Google Calendar</span>
                    </button>
                  </div>
                </div>

                {/* Feature 2: Simplify and Translate */}
                <NoticeSummary
                  analysis={activeAnalysis}
                  onOpenCalendarReview={() => setShowCalendarReview(true)}
                />

                {/* Feature 3: Action Checklist */}
                <ActionChecklist
                  actionItems={activeAnalysis.actionItems}
                  onToggleComplete={handleToggleComplete}
                  onUpdateAction={handleUpdateAction}
                  onOpenCalendarReview={() => setShowCalendarReview(true)}
                  onOpenTasksSync={handleOpenTasksSync}
                />

                {/* Feature 3: Fact List & Source Quotations */}
                <FactList facts={activeAnalysis.facts} />
              </div>
            ) : (
              /* Notice Uploader View */
              <NoticeUploader
                onAnalyze={handleAnalyzeNotice}
                onLoadSample={handleLoadSample}
                isProcessing={isProcessing}
                processingStage={processingStage}
                externalError={analysisError}
                onRetry={lastPayload ? handleRetry : undefined}
              />
            )}
          </>
        )}

        {currentTab === 'notices' && (
          <MyNoticesView
            notices={savedNotices}
            onOpenNotice={(notice) => {
              setActiveAnalysis(notice);
              setCurrentTab('home');
            }}
            onDeleteNotice={handleDeleteNotice}
            onNavigateHome={() => {
              setActiveAnalysis(null);
              setCurrentTab('home');
            }}
          />
        )}

        {currentTab === 'actions' && (
          <ActionItemsView
            actionItems={allActions}
            onToggleComplete={handleToggleNoticeAction}
            onUpdateAction={(noticeId, actionId, updates) => {
              updateActionItem(noticeId, actionId, updates);
              setSavedNotices(getNotices());
              if (activeAnalysis && activeAnalysis.id === noticeId) {
                setActiveAnalysis({
                  ...activeAnalysis,
                  actionItems: (activeAnalysis.actionItems || []).map((a) =>
                    a.id === actionId ? { ...a, ...updates } : a
                  ),
                });
              }
            }}
            onOpenNotice={(noticeId) => {
              const notice = savedNotices.find((n) => n.id === noticeId);
              if (notice) {
                setActiveAnalysis(notice);
                setCurrentTab('home');
              }
            }}
            onOpenTasksSync={handleOpenTasksSync}
          />
        )}

        {currentTab === 'myday' && (
          <MyDayPlanner
            savedNotices={savedNotices}
            allActionItems={allActions}
            onToggleActionItem={handleToggleNoticeAction}
            onOpenGoogleTasksSync={handleOpenTasksSync}
            onOpenNotice={(noticeId: string) => {
              const notice = savedNotices.find((n) => n.id === noticeId);
              if (notice) {
                setActiveAnalysis(notice);
                setCurrentTab('home');
              }
            }}
          />
        )}

        {currentTab === 'calendar' && (
          <CalendarView
            user={user}
            onConnectCalendar={handleConnectCalendar}
            onDisconnectCalendar={handleDisconnectCalendar}
            savedNotices={savedNotices}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            user={user}
            onConnectCalendar={handleConnectCalendar}
            onDisconnectCalendar={handleDisconnectCalendar}
            onClearAllData={handleClearAllData}
          />
        )}
      </main>

      {/* Floating Ask NoticeMate AI trigger button */}
      {!isChatOpen && (
        <button
          type="button"
          onClick={() => setIsChatOpen(true)}
          className="fixed bottom-20 sm:bottom-8 right-5 z-40 px-4 py-3 rounded-2xl bg-[#8273B8] hover:bg-[#7263A8] active:scale-95 text-white shadow-xl flex items-center gap-2.5 transition-all hover:scale-105 cursor-pointer font-bold text-xs sm:text-sm border border-white/20"
          title="Open NoticeMate AI Academic Assistant"
          aria-label="Open AI Assistant"
        >
          <Bot className="w-5 h-5 text-white" />
          <span>Ask NoticeMate</span>
          <span className="w-2.5 h-2.5 rounded-full bg-[#4D7C5D] animate-pulse" />
        </button>
      )}

      {/* AI Chat Assistant Drawer / Panel */}
      <AIChatPanel
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        savedNotices={savedNotices}
        activeNotice={activeAnalysis}
        onNavigateToTab={(tab) => setCurrentTab(tab)}
        onOpenTasksSyncModal={handleOpenTasksSync}
      />

      {/* Google Tasks Sync Modal */}
      <GoogleTasksSyncModal
        isOpen={isTasksSyncModalOpen}
        onClose={() => setIsTasksSyncModalOpen(false)}
        user={user}
        onConnectAccount={handleConnectCalendar}
        actionItems={tasksSyncItems}
        onTasksSynced={(syncedTasks) => {
          handleTasksSynced(syncedTasks.map((t) => t.actionId));
        }}
      />

      {/* Calendar Event Review Modal */}
      {showCalendarReview && activeAnalysis && (
        <CalendarEventReview
          analysis={activeAnalysis}
          user={user}
          onConnectCalendar={handleConnectCalendar}
          onClose={() => setShowCalendarReview(false)}
          onEventsSynced={handleEventsSynced}
        />
      )}

      {/* Floating Audio Controller */}
      <AudioBar />

      {/* Footer */}
      <footer className="mt-auto border-t border-[#EAE4E8] bg-white/60 py-6 text-center text-xs text-[#6F6B78]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="font-medium">
            <strong>Notice Mate</strong> • From Notice to Action.
          </p>
          <p className="text-[#9C98A5]">
            Built with Gemini AI & Google Calendar Integration. All documents processed securely.
          </p>
        </div>
      </footer>
    </div>
  );
}
