import { NoticeAnalysis } from '../types/notice';

export interface SampleNoticePreset {
  id: string;
  name: string;
  tag: string;
  description: string;
  rawText: string;
  preparsedAnalysis: NoticeAnalysis;
}

export const SAMPLE_NOTICES: SampleNoticePreset[] = [
  {
    id: 'sample-exam-2026',
    name: 'University Semester Examination & Fee Circular',
    tag: 'Academic / Exams',
    description: 'B.Tech/B.Sc Winter 2026 Examination schedule, form submission cutoff, late fees, and hall ticket dates.',
    rawText: `CENTRAL METROPOLITAN UNIVERSITY
OFFICE OF THE CONTROLLER OF EXAMINATIONS
Ref No: CMU/COE/EXAM-2026/1042
Date of Notification: October 20, 2026

CIRCULAR: SEMESTER-END REGULAR & BACKLOG EXAMINATIONS (NOVEMBER-DECEMBER 2026)

All candidates enrolled in Undergraduate (B.Tech, B.Sc, B.Com, B.A.) Semester III, V, and VII are hereby notified regarding the schedule for form submission and fee payment for the upcoming Semester Examinations:

1. Important Deadlines:
- Submission of Examination Form without late fee: November 12, 2026 (up to 5:00 PM).
- Submission of Examination Form with Late Fee of Rs. 500: November 18, 2026 (up to 5:00 PM).
- Absolutely NO applications will be accepted after November 18, 2026 under any circumstance.
- Release and Download of E-Admit Cards / Hall Tickets: November 24, 2026 from 10:00 AM onwards on university portal.
- Commencement of Practical & Lab Examinations: November 28, 2026.
- Commencement of Theory Examinations: December 05, 2026.

2. Prescribed Fees:
- Regular Examination Fee: Rs. 1,850/- per candidate.
- Backlog Paper Fee: Rs. 400/- per subject (maximum Rs. 1,600/-).
- Late submission surcharge: Rs. 500/-.
- Payment mode: Online only via Student Portal (credit/debit/UPI/netbanking). Offline cash or cheques are strictly rejected.

3. Mandatory Eligibility Criteria:
- Candidates must possess a minimum of 75% attendance in both lectures and practical sessions. Students with attendance between 65% and 74% may apply for condonation with valid medical proof on or before November 10, 2026.
- All library books and laboratory equipment dues must be cleared prior to form submission.

4. Required Documents to Upload:
- Scanned recent passport-size photograph (35mm x 45mm, JPEG format, under 100 KB).
- Digital signature in blue/black ink (under 50 KB).
- Previous semester grade card / marksheet copy.
- College ID card copy.

Note: Printed confirmation slip along with fee receipt must be deposited at the respective Departmental Dean's office by November 20, 2026.

By Order,
Dr. R. K. Sharma
Controller of Examinations`,
    preparsedAnalysis: {
      id: 'sample-exam-2026',
      title: 'Semester-End Regular & Backlog Examinations (November-December 2026)',
      issuingOrganization: 'Central Metropolitan University - Office of the Controller of Examinations',
      noticeReferenceNo: 'CMU/COE/EXAM-2026/1042',
      announcementDate: '2026-10-20',
      category: 'Examination',
      simpleSummary: {
        en: {
          quickSummary: 'This circular announces the schedule and requirements for undergraduate semester exams. Students must fill their exam form online, pay the exam fee, and meet the 75% attendance rule before taking their exams.',
          whatThisMeansForYou: 'If you are in Semester 3, 5, or 7, you need to submit your exam form and fee by November 12, 2026 to avoid a Rs. 500 late penalty. Download your admit card on November 24 before practical exams begin on November 28.',
          importantInstructions: [
            'Fill out the online exam form on the university student portal before 5:00 PM on November 12, 2026.',
            'Pay the examination fee of Rs. 1,850 online (cash and cheques are not allowed).',
            'Download your Hall Ticket starting November 24, 2026.',
            'Submit a physical copy of the payment receipt and confirmation slip to your Dean by November 20, 2026.'
          ],
          conditionsAndEligibility: [
            'Must have at least 75% attendance in lectures and labs.',
            'Attendance between 65% and 74% requires an approved medical condonation by November 10, 2026.',
            'All library and lab dues must be cleared first.'
          ],
          requiredDocuments: [
            'Recent passport-size photograph (under 100 KB, JPEG)',
            'Digital signature (under 50 KB)',
            'Previous semester grade card / marksheet',
            'College Identity Card copy'
          ],
          feesAndPenalties: [
            'Regular Exam Fee: Rs. 1,850',
            'Backlog Fee: Rs. 400 per subject',
            'Late fee penalty after Nov 12: Rs. 500 (final cutoff Nov 18, 5:00 PM)'
          ]
        },
        hi: {
          quickSummary: 'यह नोटिस सेमेस्टर परीक्षाओं के परीक्षा फॉर्म भरने, शुल्क भुगतान और परीक्षा तिथियों की घोषणा करता है। सभी छात्रों को 75% उपस्थिति के साथ समय पर फॉर्म भरना आवश्यक है।',
          whatThisMeansForYou: 'यदि आप सेमेस्टर 3, 5, या 7 के छात्र हैं, तो 12 नवंबर 2026 तक बिना लेट फीस के फॉर्म भरें। 24 नवंबर से एडमिट कार्ड डाउनलोड करें। प्रैक्टिकल परीक्षाएं 28 नवंबर से शुरू होंगी।',
          importantInstructions: [
            '12 नवंबर 2026 शाम 5:00 बजे तक स्टूडेंट पोर्टल पर ऑनलाइन फॉर्म भरें।',
            '1,850 रुपये का परीक्षा शुल्क ऑनलाइन जमा करें (नकद स्वीकार नहीं होगा)।',
            '24 नवंबर 2026 को सुबह 10 बजे से हॉल टिकट डाउनलोड करें।',
            '20 नवंबर 2026 तक फीस रसीद और स्लिप अपने डीन कार्यालय में जमा करें।'
          ],
          conditionsAndEligibility: [
            'कक्षाओं और प्रैक्टिकल में न्यूनतम 75% उपस्थिति अनिवार्य है।',
            '65% से 74% उपस्थिति वाले छात्र 10 नवंबर तक मेडिकल छूट के लिए आवेदन कर सकते हैं।',
            'लाइब्रेरी व लैब का कोई बकाया नहीं होना चाहिए।'
          ],
          requiredDocuments: [
            'पासपोर्ट साइज फोटो (100 KB से कम, JPEG)',
            'डिजिटल हस्ताक्षर (50 KB से कम)',
            'पिछले सेमेस्टर की मार्कशीट',
            'कॉलेज आईडी कार्ड की प्रति'
          ],
          feesAndPenalties: [
            'नियमित परीक्षा शुल्क: ₹1,850',
            'बैकलॉग पेपर शुल्क: ₹400 प्रति विषय',
            '12 नवंबर के बाद लेट फीस: ₹500 (अंतिम तिथि 18 नवंबर शाम 5 बजे)'
          ]
        }
      },
      facts: [
        {
          id: 'f1',
          category: 'deadline',
          title: 'Normal Exam Form Cutoff',
          description: 'Last date to submit examination form without penalty.',
          sourceQuote: 'Submission of Examination Form without late fee: November 12, 2026 (up to 5:00 PM).',
          pageOrSection: 'Section 1: Important Deadlines',
          importance: 'high'
        },
        {
          id: 'f2',
          category: 'deadline',
          title: 'Late Fee Form Cutoff',
          description: 'Absolute final deadline with Rs. 500 late surcharge.',
          sourceQuote: 'Submission of Examination Form with Late Fee of Rs. 500: November 18, 2026 (up to 5:00 PM).',
          pageOrSection: 'Section 1: Important Deadlines',
          importance: 'high'
        },
        {
          id: 'f3',
          category: 'exam',
          title: 'Practical Exams Commencement',
          description: 'Lab and practical evaluations start across all departments.',
          sourceQuote: 'Commencement of Practical & Lab Examinations: November 28, 2026.',
          pageOrSection: 'Section 1: Important Deadlines',
          importance: 'high'
        },
        {
          id: 'f4',
          category: 'exam',
          title: 'Theory Examinations Start',
          description: 'Final written theory examinations commence.',
          sourceQuote: 'Commencement of Theory Examinations: December 05, 2026.',
          pageOrSection: 'Section 1: Important Deadlines',
          importance: 'high'
        },
        {
          id: 'f5',
          category: 'eligibility',
          title: '75% Attendance Requirement',
          description: 'Students must have 75% attendance to be eligible for admit card.',
          sourceQuote: 'Candidates must possess a minimum of 75% attendance in both lectures and practical sessions.',
          pageOrSection: 'Section 3: Mandatory Eligibility Criteria',
          importance: 'high'
        },
        {
          id: 'f6',
          category: 'fee',
          title: 'Exam Fee Amount',
          description: 'Rs. 1,850 payable strictly online via student portal.',
          sourceQuote: 'Regular Examination Fee: Rs. 1,850/- per candidate. Payment mode: Online only via Student Portal.',
          pageOrSection: 'Section 2: Prescribed Fees',
          importance: 'medium'
        }
      ],
      actionItems: [
        {
          id: 'a1',
          title: 'Submit Examination Form Online',
          description: 'Complete the subject selection on student portal before the regular deadline.',
          dueDate: '2026-11-12',
          dueTime: '17:00',
          isAllDay: false,
          isDeadlinePassed: false,
          isDateAmbiguous: false,
          sourceQuote: 'Submission of Examination Form without late fee: November 12, 2026 (up to 5:00 PM).',
          category: 'form_submission',
          completed: false
        },
        {
          id: 'a2',
          title: 'Pay Exam Fee of Rs. 1,850',
          description: 'Pay online via UPI or Netbanking and download the payment receipt PDF.',
          dueDate: '2026-11-12',
          dueTime: '17:00',
          isAllDay: false,
          isDeadlinePassed: false,
          isDateAmbiguous: false,
          sourceQuote: 'Regular Examination Fee: Rs. 1,850/- per candidate. Payment mode: Online only via Student Portal.',
          category: 'payment',
          completed: false
        },
        {
          id: 'a3',
          title: 'Submit Physical Slip to Dean Office',
          description: 'Deposit the printed confirmation slip with receipt at Departmental Dean office.',
          dueDate: '2026-11-20',
          dueTime: '17:00',
          isAllDay: false,
          isDeadlinePassed: false,
          isDateAmbiguous: false,
          sourceQuote: 'Printed confirmation slip along with fee receipt must be deposited at the respective Departmental Dean\'s office by November 20, 2026.',
          category: 'verification',
          completed: false
        },
        {
          id: 'a4',
          title: 'Download E-Admit Card / Hall Ticket',
          description: 'Login to portal and print hall ticket for exam entry.',
          dueDate: '2026-11-24',
          dueTime: '10:00',
          isAllDay: false,
          isDeadlinePassed: false,
          isDateAmbiguous: false,
          sourceQuote: 'Release and Download of E-Admit Cards / Hall Tickets: November 24, 2026 from 10:00 AM onwards on university portal.',
          category: 'document_prep',
          completed: false
        }
      ],
      calendarEvents: [
        {
          id: 'ev1',
          title: 'Semester Exam Form Deadline (No Late Fee)',
          description: 'Deadline to submit exam form and Rs. 1850 fee on student portal without penalty.',
          startDate: '2026-11-12',
          startTime: '17:00',
          endDate: '2026-11-12',
          endTime: '17:00',
          isAllDay: false,
          eventType: 'deadline',
          sourceQuote: 'Submission of Examination Form without late fee: November 12, 2026 (up to 5:00 PM).',
          isAmbiguous: false,
          selected: true,
          reminders: [1440, 60]
        },
        {
          id: 'ev2',
          title: 'Download Hall Ticket / Admit Card',
          description: 'E-Admit cards available for download on university portal.',
          startDate: '2026-11-24',
          startTime: '10:00',
          endDate: '2026-11-24',
          endTime: '12:00',
          isAllDay: false,
          eventType: 'submission',
          sourceQuote: 'Release and Download of E-Admit Cards / Hall Tickets: November 24, 2026 from 10:00 AM onwards.',
          isAmbiguous: false,
          selected: true,
          reminders: [1440]
        },
        {
          id: 'ev3',
          title: 'Commencement of Practical Exams',
          description: 'Lab practical and viva evaluations begin.',
          startDate: '2026-11-28',
          endDate: '2026-11-28',
          isAllDay: true,
          eventType: 'exam',
          sourceQuote: 'Commencement of Practical & Lab Examinations: November 28, 2026.',
          isAmbiguous: false,
          selected: true,
          reminders: [4320, 1440]
        },
        {
          id: 'ev4',
          title: 'Theory Examinations Begin',
          description: 'Written semester examinations start.',
          startDate: '2026-12-05',
          endDate: '2026-12-05',
          isAllDay: true,
          eventType: 'exam',
          sourceQuote: 'Commencement of Theory Examinations: December 05, 2026.',
          isAmbiguous: false,
          selected: true,
          reminders: [4320, 1440]
        }
      ],
      originalExtractedText: `CENTRAL METROPOLITAN UNIVERSITY
CIRCULAR: SEMESTER-END REGULAR & BACKLOG EXAMINATIONS (NOVEMBER-DECEMBER 2026)
Submission of Examination Form without late fee: November 12, 2026 (up to 5:00 PM).
Submission of Examination Form with Late Fee of Rs. 500: November 18, 2026 (up to 5:00 PM).
Release of Admit Cards: November 24, 2026. Practical Exams: November 28, 2026. Theory Exams: December 05, 2026.
Fee: Rs. 1,850 online. Minimum 75% attendance required.`,
      rawInputType: 'text',
      fileName: 'cmu_exam_circular_nov2026.pdf',
      createdAt: new Date().toISOString(),
      processingNotes: [
        'All deadlines explicitly have confirmed year 2026 and time specifications.',
        'Strict attendance eligibility criterion detected.'
      ]
    }
  },
  {
    id: 'sample-scholarship-2026',
    name: 'National Merit-cum-Means Scholarship Notice',
    tag: 'Financial / Scholarship',
    description: 'Post-Matric Scholarship Scheme for 2026-27: Online portal cutoff, income certificate, and physical document verification.',
    rawText: `DIRECTORATE OF HIGHER EDUCATION & SOCIAL WELFARE
STATE SCHOLARSHIP CELL, NOTIFICATION NO. SCH/2026-27/089
Date: October 15, 2026

PUBLIC NOTICE: NATIONAL POST-MATRIC & MERIT-CUM-MEANS SCHOLARSHIPS 2026-27

Eligible students pursuing professional and non-professional courses in recognized institutions are invited to apply for the annual state merit scholarship:

1. Key Schedule & Timelines:
- Portal Opening for New and Renewal Applications: October 25, 2026.
- Final Cutoff for Online Application Submission: November 30, 2026 (11:59 PM).
- Institute Level Verification & Endorsement: December 10, 2026.
- Physical Verification of Original Certificates at District Nodal Centre: December 18, 2026 to December 22, 2026.
- Direct Benefit Transfer (DBT) Disbursal: January 15, 2027.

2. Eligibility Requirements:
- Annual parental/family income from all sources must not exceed Rs. 2,50,000/- per annum.
- Candidate must have secured at least 60% marks in the qualifying examination (55% for SC/ST/PwD).
- Must have an active bank account seeded with Aadhaar for DBT.

3. Mandatory Documents Required:
- Income Certificate issued by competent Revenue Authority (Tahsildar/SDM) issued after April 01, 2026.
- Caste Certificate / Community Certificate (if applicable).
- Aadhaar Card copy linked to mobile number.
- Bank Passbook front page showing Account No and IFSC.
- Current Year College Fee Receipt and Bonafide Certificate.

Caution: Incomplete applications or certificates missing digital signatures will be rejected without notice.`,
    preparsedAnalysis: {
      id: 'sample-scholarship-2026',
      title: 'National Post-Matric & Merit-Cum-Means Scholarships 2026-27',
      issuingOrganization: 'Directorate of Higher Education & Social Welfare - State Scholarship Cell',
      noticeReferenceNo: 'SCH/2026-27/089',
      announcementDate: '2026-10-15',
      category: 'Scholarship',
      simpleSummary: {
        en: {
          quickSummary: 'This notice invites applications for the 2026-27 Merit Scholarship. Eligible students with family income under Rs. 2.5 Lakhs can receive financial assistance directly into their bank accounts.',
          whatThisMeansForYou: 'You can apply online on the scholarship portal until November 30, 2026. Make sure your income certificate was issued after April 1, 2026, and your bank account is Aadhaar-linked.',
          importantInstructions: [
            'Submit your application online on the portal before November 30, 2026, 11:59 PM.',
            'Ensure your college principal or nodal officer verifies your form by December 10, 2026.',
            'Visit the District Nodal Centre with original documents between December 18 and 22, 2026.',
            'Verify that your bank account is seeded with Aadhaar for Direct Benefit Transfer.'
          ],
          conditionsAndEligibility: [
            'Total annual family income must not exceed Rs. 2,50,000 per year.',
            'Minimum 60% marks in previous qualifying exam (55% for SC/ST/PwD).',
            'Cannot hold any other central or state scholarship concurrently.'
          ],
          requiredDocuments: [
            'Income Certificate issued after April 01, 2026 by Tahsildar/SDM',
            'Aadhaar card copy linked with phone number',
            'Caste / Community Certificate',
            'Bank passbook showing account number and IFSC',
            'Current year college fee receipt and Bonafide certificate'
          ],
          feesAndPenalties: [
            'Application fee: Free of cost.',
            'Late applications will not be entertained after Nov 30 cutoff.'
          ]
        },
        hi: {
          quickSummary: 'यह नोटिस वर्ष 2026-27 के लिए मेरिट-कम-मीन्स छात्रवृत्ति के आवेदन आमंत्रित करता है। 2.5 लाख से कम पारिवारिक आय वाले पात्र छात्र इसके लिए आवेदन कर सकते हैं।',
          whatThisMeansForYou: 'आप 30 नवंबर 2026 तक ऑनलाइन आवेदन कर सकते हैं। अपनी आय प्रमाण पत्र और आधार-लिंक्ड बैंक खाते की जानकारी तैयार रखें।',
          importantInstructions: [
            '30 नवंबर 2026 रात 11:59 बजे से पहले ऑनलाइन आवेदन पूरा करें।',
            '10 दिसंबर 2026 तक कॉलेज स्तर पर सत्यापन करवाएं।',
            '18 से 22 दिसंबर के बीच जिला केंद्र पर मूल दस्तावेजों का भौतिक सत्यापन कराएं।'
          ],
          conditionsAndEligibility: [
            'परिवार की वार्षिक आय ₹2,50,000 से अधिक नहीं होनी चाहिए।',
            'पिछली परीक्षा में न्यूनतम 60% अंक (एससी/एसटी/दिव्यांग के लिए 55%)।',
            'आधार से जुड़ा बैंक खाता होना अनिवार्य है।'
          ],
          requiredDocuments: [
            '01 अप्रैल 2026 के बाद जारी आय प्रमाण पत्र',
            'जाति प्रमाण पत्र (यदि लागू हो)',
            'आधार कार्ड की प्रति',
            'बैंक पासबुक की प्रति',
            'कॉलेज फीस रसीद और बोनाफाइड सर्टिफिकेट'
          ],
          feesAndPenalties: [
            'आवेदन शुल्क: नि:शुल्क',
            '30 नवंबर के बाद पोर्टल बंद हो जाएगा।'
          ]
        }
      },
      facts: [
        {
          id: 'sf1',
          category: 'deadline',
          title: 'Online Application Cutoff',
          description: 'Last time to register and submit online scholarship form.',
          sourceQuote: 'Final Cutoff for Online Application Submission: November 30, 2026 (11:59 PM).',
          pageOrSection: 'Section 1: Key Schedule & Timelines',
          importance: 'high'
        },
        {
          id: 'sf2',
          category: 'deadline',
          title: 'Physical Document Verification',
          description: 'Original certificate checking at District Nodal Centre.',
          sourceQuote: 'Physical Verification of Original Certificates at District Nodal Centre: December 18, 2026 to December 22, 2026.',
          pageOrSection: 'Section 1: Key Schedule & Timelines',
          importance: 'high'
        },
        {
          id: 'sf3',
          category: 'eligibility',
          title: 'Family Income Ceiling',
          description: 'Income must not exceed Rs. 2.5 Lakhs per year.',
          sourceQuote: 'Annual parental/family income from all sources must not exceed Rs. 2,50,000/- per annum.',
          pageOrSection: 'Section 2: Eligibility Requirements',
          importance: 'high'
        }
      ],
      actionItems: [
        {
          id: 'sa1',
          title: 'Obtain Revenue Income Certificate',
          description: 'Make sure income certificate is issued after April 1, 2026 with digital barcode.',
          dueDate: '2026-11-20',
          dueTime: null,
          isAllDay: true,
          isDeadlinePassed: false,
          isDateAmbiguous: false,
          sourceQuote: 'Income Certificate issued by competent Revenue Authority (Tahsildar/SDM) issued after April 01, 2026.',
          category: 'document_prep',
          completed: false
        },
        {
          id: 'sa2',
          title: 'Submit Online Scholarship Form',
          description: 'Complete registration on state scholarship portal before deadline.',
          dueDate: '2026-11-30',
          dueTime: '23:59',
          isAllDay: false,
          isDeadlinePassed: false,
          isDateAmbiguous: false,
          sourceQuote: 'Final Cutoff for Online Application Submission: November 30, 2026 (11:59 PM).',
          category: 'form_submission',
          completed: false
        },
        {
          id: 'sa3',
          title: 'Attend District Physical Verification',
          description: 'Take all original certificates and 2 photocopies to District Nodal Centre.',
          dueDate: '2026-12-18',
          dueTime: '10:00',
          isAllDay: false,
          isDeadlinePassed: false,
          isDateAmbiguous: false,
          sourceQuote: 'Physical Verification of Original Certificates at District Nodal Centre: December 18, 2026 to December 22, 2026.',
          category: 'verification',
          completed: false
        }
      ],
      calendarEvents: [
        {
          id: 'sev1',
          title: 'Scholarship Application Cutoff',
          description: 'Deadline to submit national post-matric scholarship application on portal.',
          startDate: '2026-11-30',
          startTime: '23:59',
          endDate: '2026-11-30',
          endTime: '23:59',
          isAllDay: false,
          eventType: 'deadline',
          sourceQuote: 'Final Cutoff for Online Application Submission: November 30, 2026 (11:59 PM).',
          isAmbiguous: false,
          selected: true,
          reminders: [4320, 1440, 120]
        },
        {
          id: 'sev2',
          title: 'Scholarship Physical Document Verification',
          description: 'Visit District Nodal Centre with original income and caste certificates.',
          startDate: '2026-12-18',
          startTime: '10:00',
          endDate: '2026-12-18',
          endTime: '16:00',
          isAllDay: false,
          eventType: 'verification',
          sourceQuote: 'Physical Verification of Original Certificates at District Nodal Centre: December 18, 2026 to December 22, 2026.',
          isAmbiguous: false,
          selected: true,
          reminders: [1440]
        }
      ],
      originalExtractedText: `PUBLIC NOTICE: NATIONAL POST-MATRIC & MERIT-CUM-MEANS SCHOLARSHIPS 2026-27
Final Cutoff for Online Application Submission: November 30, 2026 (11:59 PM).
Institute Level Verification: December 10, 2026.
Physical Verification of Original Certificates at District Nodal Centre: December 18-22, 2026.
Annual income must not exceed Rs. 2,50,000/-. Income certificate after April 01, 2026 required.`,
      rawInputType: 'text',
      fileName: 'scholarship_notice_2026_27.pdf',
      createdAt: new Date().toISOString(),
      processingNotes: [
        'Confirmed deadlines and verified income limit restrictions.'
      ]
    }
  }
];
